const DEFAULT_CONTEXT = {
  businessType: '咖啡店',
  businessTypeIndex: 0,
  investmentBudget: 35,
  storeArea: 45,
  rentCeiling: 2,
  avgTicket: 18,
  includeBusinessParams: true,
  includeCandidatePool: true
};

Page({
  data: {
    businessTypes: ['咖啡店', '茶饮店', '便利店', '轻餐饮', '美业门店'],
    businessType: DEFAULT_CONTEXT.businessType,
    businessTypeIndex: DEFAULT_CONTEXT.businessTypeIndex,
    investmentBudget: DEFAULT_CONTEXT.investmentBudget,
    storeArea: DEFAULT_CONTEXT.storeArea,
    rentCeiling: DEFAULT_CONTEXT.rentCeiling,
    avgTicket: DEFAULT_CONTEXT.avgTicket,
    includeBusinessParams: DEFAULT_CONTEXT.includeBusinessParams,
    includeCandidatePool: DEFAULT_CONTEXT.includeCandidatePool,
    candidatePool: [],
    activeCandidateId: ''
  },

  onLoad() {
    this.loadContext();
  },

  loadContext() {
    const saved = wx.getStorageSync('siteDecisionContext') || {};
    const candidatePool = wx.getStorageSync('candidatePool') || [];
    const businessType = saved.businessType || DEFAULT_CONTEXT.businessType;
    const businessTypeIndex = Math.max(0, this.data.businessTypes.indexOf(businessType));

    this.setData({
      businessType,
      businessTypeIndex,
      investmentBudget: Number(saved.investmentBudget || DEFAULT_CONTEXT.investmentBudget),
      storeArea: Number(saved.storeArea || DEFAULT_CONTEXT.storeArea),
      rentCeiling: Number(saved.rentCeiling || DEFAULT_CONTEXT.rentCeiling),
      avgTicket: Number(saved.avgTicket || DEFAULT_CONTEXT.avgTicket),
      includeBusinessParams: saved.includeBusinessParams !== false,
      includeCandidatePool: saved.includeCandidatePool !== false,
      candidatePool,
      activeCandidateId: wx.getStorageSync('activeCandidateId') || ''
    });
  },

  saveContext() {
    wx.setStorageSync('siteDecisionContext', {
      businessType: this.data.businessType,
      investmentBudget: Number(this.data.investmentBudget || 0),
      storeArea: Number(this.data.storeArea || 0),
      rentCeiling: Number(this.data.rentCeiling || 0),
      avgTicket: Number(this.data.avgTicket || 0),
      includeBusinessParams: this.data.includeBusinessParams,
      includeCandidatePool: this.data.includeCandidatePool
    });
    wx.setStorageSync('candidatePool', this.data.candidatePool);
    wx.setStorageSync('activeCandidateId', this.data.activeCandidateId);
  },

  toggleBusinessParams(e) {
    this.setData({ includeBusinessParams: e.detail.value });
    this.saveContext();
  },

  toggleCandidatePool(e) {
    this.setData({ includeCandidatePool: e.detail.value });
    this.saveContext();
  },

  onBusinessTypeChange(e) {
    const index = Number(e.detail.value || 0);
    const businessType = this.data.businessTypes[index] || this.data.businessTypes[0];
    const presets = {
      咖啡店: { investmentBudget: 45, storeArea: 80, rentCeiling: 5, avgTicket: 32 },
      茶饮店: { investmentBudget: 35, storeArea: 45, rentCeiling: 4, avgTicket: 18 },
      便利店: { investmentBudget: 60, storeArea: 100, rentCeiling: 6, avgTicket: 25 },
      轻餐饮: { investmentBudget: 80, storeArea: 120, rentCeiling: 7, avgTicket: 45 },
      美业门店: { investmentBudget: 50, storeArea: 90, rentCeiling: 4, avgTicket: 168 }
    };

    this.setData(Object.assign({
      businessType,
      businessTypeIndex: index
    }, presets[businessType] || presets['咖啡店']));
    this.saveContext();
  },

  onNumberInput(e) {
    const field = e.currentTarget.dataset.field;
    if (!field) return;

    this.setData({ [field]: e.detail.value });
  },

  removeCandidate(e) {
    const id = e.currentTarget.dataset.id;
    const candidatePool = this.data.candidatePool.filter(item => item.id !== id);
    const activeCandidateId = this.data.activeCandidateId === id
      ? (candidatePool[0] ? candidatePool[0].id : '')
      : this.data.activeCandidateId;

    this.setData({ candidatePool, activeCandidateId });
    this.saveContext();
  },

  focusCandidate(e) {
    const id = e.currentTarget.dataset.id;
    const item = this.data.candidatePool.find(candidate => candidate.id === id);
    if (!item) return;

    this.setData({ activeCandidateId: id });
    this.saveContext();
    wx.setStorageSync('selectedLocation', {
      name: item.name,
      address: item.address || item.name,
      city: item.city,
      location: `${item.lng},${item.lat}`
    });
    wx.switchTab({ url: '/pages/index/index' });
  },

  saveAndBack() {
    this.saveContext();
    wx.showToast({ title: '已保存', icon: 'success' });
    setTimeout(() => {
      wx.navigateBack();
    }, 300);
  },

  goBack() {
    this.saveContext();
    wx.navigateBack();
  }
});
