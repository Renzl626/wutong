// pages/location-search/location-search.js
const amapFile = require('../../libs/amap-wx.130.js');

const AMAP_KEY = '270cacd2eeb9089758ccc278c5bba579';

const HOT_SEARCHES = [
  '万达广场', '银泰城', '华润万象城', '龙湖天街',
  '吾悦广场', '印象城', '世纪大道', '金融中心'
];

Page({
  data: {
    city: '南京市',
    searchKeyword: '',
    searchResults: [],
    activeTab: '',
    currentLocation: '定位中...',
    favorites: [],
    searchHistory: [],
    hotSearches: HOT_SEARCHES,
    isSearching: false,
    currentLat: 0,
    currentLng: 0
  },

  onLoad() {
    this.amapPlugin = new amapFile.AMapWX({ key: AMAP_KEY });
    this.initCurrentLocation();
    this.loadFavorites();
    this.loadSearchHistory();
  },

  onShow() {
    const selectedCity = wx.getStorageSync('selectedCity');
    if (selectedCity && selectedCity !== this.data.city) {
      this.setData({ city: selectedCity });
    }
  },

  initCurrentLocation() {
    this.amapPlugin.getWxLocation(
      () => {},
      {
        fail: () => {
          wx.getLocation({
            type: 'gcj02',
            success: (res) => {
              this.currentLat = res.latitude;
              this.currentLng = res.longitude;
              this.getRegeoInfo(res.longitude, res.latitude);
            },
            fail: () => {
              this.setData({ currentLocation: '定位失败' });
            }
          });
        },
        success: (location) => {
          const [longitude, latitude] = location.split(',');
          this.currentLng = parseFloat(longitude);
          this.currentLat = parseFloat(latitude);
          this.getRegeoInfo(parseFloat(longitude), parseFloat(latitude));
        }
      }
    );
  },

  getRegeoInfo(longitude, latitude) {
    this.amapPlugin.getRegeo({
      location: `${longitude},${latitude}`,
      success: (data) => {
        if (data && data.length > 0) {
          const address = data[0].name || data[0].desc || '未知位置';
          const city = data[0].regeocodeData.addressComponent.city || '南京市';
          this.setData({
            currentLocation: address,
            city: city
          });
        }
      },
      fail: () => {
        this.setData({ currentLocation: '获取地址失败' });
      }
    });
  },

  loadFavorites() {
    const favorites = wx.getStorageSync('locationFavorites') || [];
    this.setData({ favorites });
  },

  loadSearchHistory() {
    const history = wx.getStorageSync('searchHistory') || [];
    this.setData({ searchHistory: history.slice(0, 8) });
  },

  saveSearchHistory(keyword) {
    if (!keyword) return;
    let history = wx.getStorageSync('searchHistory') || [];
    history = history.filter(k => k !== keyword);
    history.unshift(keyword);
    history = history.slice(0, 8);
    wx.setStorageSync('searchHistory', history);
    this.setData({ searchHistory: history });
  },

  goBack() {
    wx.navigateBack();
  },

  onSearchInput(e) {
    const keyword = e.detail.value;
    this.setData({ searchKeyword: keyword });
  },

  doSearch(e) {
    const keyword = e?.currentTarget?.dataset?.keyword || this.data.searchKeyword.trim();
    if (!keyword) {
      wx.showToast({
        title: '请输入搜索关键词',
        icon: 'none'
      });
      return;
    }

    this.saveSearchHistory(keyword);
    this.setData({ searchResults: [], isSearching: true });

    wx.showLoading({ title: '搜索中...' });

    this.amapPlugin.getInputtips({
      keywords: keyword,
      city: this.data.city,
      citylimit: true,
      success: (data) => {
        wx.hideLoading();
        this.setData({ isSearching: false });

        if (data && data.tips && data.tips.length > 0) {
          const results = data.tips.slice(0, 15).map(item => ({
            id: item.id || item.name,
            name: item.name,
            address: item.district + item.address,
            distance: this.calculateDistance(item.location),
            location: item.location
          }));
          this.setData({
            searchResults: results,
            activeTab: ''
          });
        } else {
          this.setData({
            searchResults: []
          });
          wx.showToast({
            title: '未找到相关位置',
            icon: 'none'
          });
        }
      },
      fail: () => {
        wx.hideLoading();
        this.setData({ isSearching: false });
        wx.showToast({
          title: '搜索失败，请重试',
          icon: 'none'
        });
      }
    });
  },

  calculateDistance(location) {
    if (!location || !this.currentLat || !this.currentLng) {
      return '';
    }

    const [lng, lat] = location.split(',').map(parseFloat);
    if (!lng || !lat) return '';

    const R = 6371000;
    const dLat = (lat - this.currentLat) * Math.PI / 180;
    const dLng = (lng - this.currentLng) * Math.PI / 180;
    const a =
      Math.sin(dLat/2) * Math.sin(dLat/2) +
      Math.cos(this.currentLat * Math.PI / 180) * Math.cos(lat * Math.PI / 180) *
      Math.sin(dLng/2) * Math.sin(dLng/2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
    const distance = R * c;

    if (distance < 1000) {
      return Math.round(distance) + 'm';
    } else {
      return (distance / 1000).toFixed(1) + 'km';
    }
  },

  switchTab(tab) {
    this.setData({
      activeTab: tab,
      searchResults: [],
      searchKeyword: '',
      showSearchTips: false,
      searchTips: []
    });
  },

  selectCity() {
    wx.navigateTo({
      url: '/pages/city-select/city-select'
    });
  },

  selectLocation(e) {
    const dataset = e?.currentTarget?.dataset;
    const name = dataset?.name;
    const address = dataset?.address;
    const location = dataset?.location;

    if (!name) return;

    const locationData = {
      name: name,
      address: address || '',
      location: location || '',
      city: this.data.city,
      selectedTime: Date.now()
    };
    wx.setStorageSync('selectedLocation', locationData);

    const pages = getCurrentPages();
    for (let i = pages.length - 1; i >= 0; i--) {
      const page = pages[i];
      if (page && page.route && page.route.includes('index')) {
        if (page.setData) {
          page.setData({
            locationName: name,
            locationAddress: address || '',
            locationCoords: location || ''
          });
        }
        break;
      }
    }

    wx.showToast({
      title: `已选择: ${name}`,
      icon: 'none'
    });

    setTimeout(() => {
      wx.switchTab({
        url: '/pages/index/index'
      });
    }, 800);
  },

  clearHistory() {
    wx.showModal({
      title: '确认清除',
      content: '确定要清除所有搜索历史吗？',
      success: (res) => {
        if (res.confirm) {
          wx.removeStorageSync('searchHistory');
          this.setData({ searchHistory: [] });
        }
      }
    });
  },

  onShareAppMessage() {
    return {
      title: '智汇铺手 - 智能选址助手',
      path: '/pages/index/index'
    };
  }
});
