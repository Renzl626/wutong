const amapFile = require('../../libs/amap-wx.130.js');
const app = getApp();

const AMAP_KEY = '270cacd2eeb9089758ccc278c5bba579';
const AGENT_API_URL = 'https://api.mzhyui.cn/chat';
const DEFAULT_CONTEXT = {
  businessType: '咖啡店',
  businessTypeIndex: 0,
  investmentBudget: 35,
  storeArea: 45,
  rentCeiling: 2,
  avgTicket: 18,
  includeBusinessParams: true,
  includeCandidatePool: true
};

Page({
  data: {
    latitude: 32.06027,
    longitude: 118.76337,
    scale: 14,
    markers: [],
    circles: [],
    range: 2,
    city: '南京市',
    locationName: '',
    locationAddress: '',
    isLocating: true,
    mapContext: null,
    locationRequestId: 0,
    lastLocationName: '',

    businessTypes: ['咖啡店', '茶饮店', '便利店', '轻餐饮', '美业门店'],
    businessType: DEFAULT_CONTEXT.businessType,
    businessTypeIndex: DEFAULT_CONTEXT.businessTypeIndex,
    investmentBudget: DEFAULT_CONTEXT.investmentBudget,
    storeArea: DEFAULT_CONTEXT.storeArea,
    rentCeiling: DEFAULT_CONTEXT.rentCeiling,
    avgTicket: DEFAULT_CONTEXT.avgTicket,
    includeBusinessParams: DEFAULT_CONTEXT.includeBusinessParams,
    includeCandidatePool: DEFAULT_CONTEXT.includeCandidatePool,
    candidatePool: [],
    activeCandidateId: '',

    chatInput: '',
    chatMessages: [],
    currentChatMessages: [],
    chatExpanded: false,
    showChatHistory: false,
    chatHistory: [],
    isTyping: false,
    scrollToMessage: '',
    sessionId: '',
    sseBuffer: '',
    pendingFinalContent: ''
  },

  pendingAssistantText: '',
  flushTimer: null,
  locationDebounceTimer: null,

  onLoad() {
    this.amapPlugin = new amapFile.AMapWX({ key: AMAP_KEY });
    this.initDecisionContext();
    this.initSession();
    this.initLocation();
    this.loadChatHistory();
  },

  onShow() {
    this.initDecisionContext();

    if (typeof this.getTabBar === 'function' && this.getTabBar()) {
      this.getTabBar().setData({ selected: 0 });
    }

    this.checkSelectedLocation();
  },

  onReady() {
    this.mapContext = wx.createMapContext('mainMap');
  },

  onUnload() {
    this.clearFlushTimer();

    if (this.locationDebounceTimer) {
      clearTimeout(this.locationDebounceTimer);
      this.locationDebounceTimer = null;
    }
  },

  initDecisionContext() {
    const saved = wx.getStorageSync('siteDecisionContext') || {};
    const businessType = saved.businessType || DEFAULT_CONTEXT.businessType;
    const businessTypeIndex = Math.max(0, this.data.businessTypes.indexOf(businessType));

    this.setData({
      businessType,
      businessTypeIndex,
      investmentBudget: Number(saved.investmentBudget || DEFAULT_CONTEXT.investmentBudget),
      storeArea: Number(saved.storeArea || DEFAULT_CONTEXT.storeArea),
      rentCeiling: Number(saved.rentCeiling || DEFAULT_CONTEXT.rentCeiling),
      avgTicket: Number(saved.avgTicket || DEFAULT_CONTEXT.avgTicket),
      includeBusinessParams: saved.includeBusinessParams !== false,
      includeCandidatePool: saved.includeCandidatePool !== false,
      candidatePool: wx.getStorageSync('candidatePool') || [],
      activeCandidateId: wx.getStorageSync('activeCandidateId') || ''
    });
  },

  saveDecisionContext() {
    wx.setStorageSync('siteDecisionContext', {
      businessType: this.data.businessType,
      investmentBudget: this.data.investmentBudget,
      storeArea: this.data.storeArea,
      rentCeiling: this.data.rentCeiling,
      avgTicket: this.data.avgTicket,
      includeBusinessParams: this.data.includeBusinessParams,
      includeCandidatePool: this.data.includeCandidatePool
    });
    wx.setStorageSync('candidatePool', this.data.candidatePool);
    wx.setStorageSync('activeCandidateId', this.data.activeCandidateId);
  },

  initSession() {
    let sessionId = wx.getStorageSync('session_id');

    if (!sessionId) {
      sessionId = app && typeof app.generateUUID === 'function'
        ? app.generateUUID()
        : 'wx_' + Date.now() + '_' + Math.random().toString(16).slice(2);
      wx.setStorageSync('session_id', sessionId);
    }

    const greetingMessage = {
      role: 'assistant',
      content: '你好，我是智能选址助手。你可以先搜索点位、加入候选池，再在这里统一生成分析报告。'
    };

    this.setData({
      sessionId,
      chatMessages: [greetingMessage],
      currentChatMessages: [greetingMessage]
    });
  },

  initLocation() {
    this.setData({ isLocating: true });

    wx.getLocation({
      type: 'gcj02',
      success: (res) => {
        this.handleLocationSuccess(res.longitude, res.latitude);
      },
      fail: (err) => {
        console.error('定位失败:', err);
        this.handleLocationFail();
      }
    });
  },

  handleLocationSuccess(longitude, latitude) {
    this.setData({ longitude, latitude, isLocating: false });
    this.updateLocationName(longitude, latitude);
    this.updateMarkers(longitude, latitude);
    this.updateCircles(longitude, latitude);
  },

  handleLocationFail() {
    this.setData({
      isLocating: false,
      locationName: '定位失败'
    });

    wx.showToast({
      title: '定位失败，请检查权限',
      icon: 'none'
    });
  },

  checkSelectedLocation() {
    const selectedLocation = wx.getStorageSync('selectedLocation');

    if (!selectedLocation || !selectedLocation.name) {
      return;
    }

    const locationCoords = selectedLocation.location;

    if (locationCoords && locationCoords.includes(',')) {
      const [lng, lat] = locationCoords.split(',').map(Number);

      if (!Number.isNaN(lng) && !Number.isNaN(lat)) {
        this.setData({
          latitude: lat,
          longitude: lng,
          scale: 16,
          locationName: selectedLocation.name,
          locationAddress: selectedLocation.address || '',
          city: selectedLocation.city || this.data.city
        });

        this.updateMarkersForSelectedLocation(lng, lat, selectedLocation.name);
        this.updateCircles(lng, lat);
        wx.removeStorageSync('selectedLocation');
        return;
      }
    }

    this.setData({
      locationName: selectedLocation.name,
      locationAddress: selectedLocation.address || '',
      city: selectedLocation.city || this.data.city
    });
    wx.removeStorageSync('selectedLocation');
  },

  updateLocationName(longitude, latitude) {
    const currentRequestId = this.data.locationRequestId + 1;
    this.setData({ locationRequestId: currentRequestId });

    this.amapPlugin.getRegeo({
      location: `${longitude},${latitude}`,
      success: (data) => {
        if (currentRequestId !== this.data.locationRequestId) return;

        if (data && data.length > 0) {
          const item = data[0];
          const addressComponent = item.regeocodeData && item.regeocodeData.addressComponent;
          const newLocationName = item.name || item.desc || '未知位置';

          this.setData({
            locationName: newLocationName,
            locationAddress: item.desc || newLocationName,
            lastLocationName: newLocationName,
            city: (addressComponent && addressComponent.city) || this.data.city
          });
        }
      },
      fail: () => {
        if (currentRequestId !== this.data.locationRequestId) return;

        if (!this.data.lastLocationName) {
          this.setData({ locationName: '获取地址失败' });
        }
      }
    });
  },

  updateMarkers(longitude, latitude) {
    this.setData({
      markers: [{
        id: 0,
        longitude,
        latitude,
        width: 48,
        height: 48,
        iconPath: '/imgs/locate.png'
      }]
    });
  },

  updateMarkersForSelectedLocation(longitude, latitude, name) {
    this.setData({
      markers: [{
        id: 0,
        longitude,
        latitude,
        width: 48,
        height: 48,
        iconPath: '/imgs/locate.png',
        callout: {
          content: name,
          color: '#ffffff',
          fontSize: 12,
          borderRadius: 8,
          bgColor: '#0d6f84',
          padding: 8,
          display: 'ALWAYS'
        }
      }]
    });
  },

  updateCircles(longitude, latitude) {
    this.setData({
      circles: [{
        id: 0,
        longitude,
        latitude,
        radius: this.data.range * 1000,
        color: '#67ffd066',
        fillColor: '#67ffd01f',
        strokeWidth: 2
      }]
    });
  },

  onMapTap() {},
  onMarkerTap() {},
  onControlTap() {},

  onRegionChange(e) {
    if (!this.mapContext) return;

    this.mapContext.getCenterLocation({
      success: (res) => {
        const { longitude, latitude } = res;
        const distance = this.calculateDistance(
          this.data.longitude,
          this.data.latitude,
          longitude,
          latitude
        );

        if (distance > 5) {
          this.setData({ longitude, latitude });
          this.updateMarkers(longitude, latitude);
          this.updateCircles(longitude, latitude);

          if (e.type === 'end') {
            this.debounceUpdateLocationName(longitude, latitude);
          }
        }
      }
    });
  },

  calculateDistance(lng1, lat1, lng2, lat2) {
    const radius = 6371000;
    const dLat = this.toRad(lat2 - lat1);
    const dLng = this.toRad(lng2 - lng1);
    const a =
      Math.sin(dLat / 2) * Math.sin(dLat / 2) +
      Math.cos(this.toRad(lat1)) * Math.cos(this.toRad(lat2)) *
      Math.sin(dLng / 2) * Math.sin(dLng / 2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    return radius * c;
  },

  toRad(deg) {
    return deg * (Math.PI / 180);
  },

  debounceUpdateLocationName(longitude, latitude) {
    if (this.locationDebounceTimer) {
      clearTimeout(this.locationDebounceTimer);
    }

    this.locationDebounceTimer = setTimeout(() => {
      this.updateLocationName(longitude, latitude);
    }, 300);
  },

  onLocationBtnTap() {
    if (this.data.isLocating) return;
    this.initLocation();
  },

  refreshMap() {
    this.initLocation();
    wx.showToast({ title: '地图已刷新', icon: 'success' });
  },

  selectRange() {
    const ranges = ['1km', '2km', '3km'];

    wx.showActionSheet({
      itemList: ranges,
      success: (res) => {
        const selectedRange = parseInt(ranges[res.tapIndex], 10);
        this.setData({ range: selectedRange });
        this.updateCircles(this.data.longitude, this.data.latitude);
        wx.showToast({ title: `已选择${selectedRange}km范围`, icon: 'none' });
      }
    });
  },

  goToLocationSearch() {
    wx.setStorageSync('selectedCity', this.data.city);
    wx.navigateTo({ url: '/pages/location-search/location-search' });
  },

  goToAnalysisSettings() {
    wx.navigateTo({ url: '/pages/analysis-settings/analysis-settings' });
  },

  scoreSeed(lng, lat, salt = 0) {
    const raw = Math.abs(Math.sin(Number(lng) * 12.9898 + Number(lat) * 78.233 + salt) * 10000);
    return Math.round(raw % 100);
  },

  buildCandidateScore(lng, lat) {
    const traffic = Math.min(96, 72 + this.data.range * 2 + (this.scoreSeed(lng, lat, 1) % 12));
    const rent = Math.max(58, 88 - Math.round(Number(this.data.rentCeiling || 4) * 2) + (this.scoreSeed(lng, lat, 2) % 10));
    const competition = Math.max(55, 82 - this.data.range * 4 + (this.scoreSeed(lng, lat, 3) % 14));
    const fit = Math.min(96, 72 + (this.scoreSeed(lng, lat, this.data.businessType.length) % 18));
    const score = Math.round(traffic * 0.32 + rent * 0.22 + competition * 0.2 + fit * 0.26);
    return { score, metrics: { traffic, rent, competition, fit } };
  },

  addCurrentCandidate() {
    const lng = Number(this.data.longitude);
    const lat = Number(this.data.latitude);
    const exists = this.data.candidatePool.some(item => (
      Math.abs(item.lng - lng) < 0.00005 && Math.abs(item.lat - lat) < 0.00005
    ));

    if (exists) {
      wx.showToast({ title: '该点已在候选池', icon: 'none' });
      return;
    }

    const scored = this.buildCandidateScore(lng, lat);
    const item = {
      id: 'candidate_' + Date.now() + '_' + Math.random().toString(16).slice(2),
      name: this.data.locationName || this.data.locationAddress || '未命名候选点',
      address: this.data.locationAddress || this.data.locationName || '',
      city: this.data.city,
      lng,
      lat,
      range: this.data.range,
      businessType: this.data.businessType,
      score: scored.score,
      metrics: scored.metrics
    };

    const candidatePool = [item, ...this.data.candidatePool].slice(0, 5);
    this.setData({
      candidatePool,
      activeCandidateId: item.id,
      includeCandidatePool: true
    });
    this.saveDecisionContext();
    wx.showToast({ title: '已加入候选池', icon: 'success' });
  },

  loadChatHistory() {
    this.setData({ chatHistory: wx.getStorageSync('chatHistory') || [] });
  },

  saveChatHistory() {
    const currentMessages = this.data.currentChatMessages;
    if (!currentMessages.length) return;

    const history = this.data.chatHistory || [];
    const now = new Date();
    const time = `${now.getMonth() + 1}-${now.getDate()} ${now.getHours()}:${String(now.getMinutes()).padStart(2, '0')}`;
    const lastUserMessage = [...currentMessages].reverse().find(item => item.role === 'user');
    const preview = lastUserMessage ? lastUserMessage.content.substring(0, 24) + '...' : '新对话';
    const newSession = {
      id: Date.now(),
      time,
      preview,
      messages: [...currentMessages]
    };

    history.unshift(newSession);
    if (history.length > 20) history.pop();

    wx.setStorageSync('chatHistory', history);
    this.setData({ chatHistory: history });
  },

  toggleChatHistory() {
    this.setData({ showChatHistory: !this.data.showChatHistory });
  },

  loadChatSession(e) {
    const session = this.data.chatHistory[e.currentTarget.dataset.index];
    if (!session) return;

    this.setData({
      currentChatMessages: session.messages,
      chatMessages: session.messages,
      showChatHistory: false
    });
    this.scrollToBottom();
  },

  toggleChatExpand() {
    this.setData({ chatExpanded: !this.data.chatExpanded });
  },

  onChatInput(e) {
    this.setData({ chatInput: e.detail.value });
  },

  fillChatDraft(question) {
    this.setData({ chatInput: question });
    wx.showToast({ title: '已写入对话框', icon: 'none' });
  },

  fillQuickQuestion(e) {
    this.fillChatDraft(e.currentTarget.dataset.question || '');
  },

  fillReportDraft() {
    this.fillChatDraft('请基于当前点位、分析设置和我的补充要求，生成一份结构化商铺选址分析报告。');
  },

  sendChatMessage() {
    const input = this.data.chatInput.trim();

    if (!input) return;

    if (this.data.isTyping) {
      wx.showToast({ title: '正在分析中，请稍等', icon: 'none' });
      return;
    }

    const userMessage = { role: 'user', content: input };
    const assistantMessage = { role: 'assistant', content: '正在分析，请稍等...' };
    const newMessages = [...this.data.currentChatMessages, userMessage, assistantMessage];

    this.setData({
      currentChatMessages: newMessages,
      chatMessages: newMessages,
      chatInput: '',
      isTyping: true,
      sseBuffer: '',
      pendingFinalContent: '',
      showChatHistory: false
    });

    this.pendingAssistantText = '';
    this.clearFlushTimer();
    this.scrollToBottom();

    const contextInfo = this.buildContextInfo();
    this.startSSE(contextInfo ? `${input}\n\n${contextInfo}` : input);
  },

  buildContextInfo() {
    const {
      locationName,
      city,
      range,
      longitude,
      latitude,
      includeBusinessParams,
      includeCandidatePool,
      businessType,
      investmentBudget,
      storeArea,
      rentCeiling,
      avgTicket,
      candidatePool
    } = this.data;

    if (!locationName || locationName === '定位失败') {
      return '';
    }

    const context = [
      '【当前选址上下文】',
      `位置：${locationName}`,
      `城市：${city}`,
      `调研范围：${range}km`,
      `经纬度：${longitude},${latitude}`
    ];

    if (includeBusinessParams) {
      context.push(
        '',
        '【AI选址参数】',
        `目标业态：${businessType}`,
        `投资预算：${investmentBudget}万元`,
        `目标面积：${storeArea}㎡`,
        `月租上限：${rentCeiling}万元`,
        `客单价假设：${avgTicket}元`
      );
    } else {
      context.push('', '【AI选址参数】本次未纳入。');
    }

    if (includeCandidatePool) {
      context.push('', '【候选点对比池】', this.buildCandidateContext(candidatePool));
    } else {
      context.push('', '【候选点对比池】本次未纳入。');
    }

    return context.join('\n');
  },

  buildCandidateContext(candidatePool) {
    if (!candidatePool || !candidatePool.length) return '暂无候选点。';

    return candidatePool.map((item, index) => ([
      `${index + 1}. ${item.name}`,
      `城市：${item.city}`,
      `坐标：${item.lng},${item.lat}`,
      `半径：${item.range}km`,
      `综合评分：${item.score}`,
      `客流：${item.metrics.traffic}，租金健康：${item.metrics.rent}，竞品空隙：${item.metrics.competition}，业态匹配：${item.metrics.fit}`
    ].join('\n'))).join('\n\n');
  },

  scrollToBottom() {
    setTimeout(() => {
      const len = this.data.currentChatMessages.length;
      if (len > 0) this.setData({ scrollToMessage: `msg-${len - 1}` });
    }, 100);
  },

  startSSE(userMessage) {
    const sessionId = this.data.sessionId || ('wx_' + Date.now());
    const requestTask = wx.request({
      url: AGENT_API_URL,
      method: 'POST',
      data: { message: userMessage, sessionId },
      header: {
        'content-type': 'application/json',
        Accept: 'text/event-stream'
      },
      enableChunked: true,
      timeout: 300000,
      success: () => {
        this.flushSSEBuffer();
        this.flushAssistantText();

        if (this.data.pendingFinalContent) {
          const reportJson = this.tryParseReportJson(this.data.pendingFinalContent);
          if (reportJson) this.handleParsedReport(reportJson);
        }

        this.setData({ pendingFinalContent: '', isTyping: false });
        this.saveChatHistory();
      },
      fail: (err) => {
        console.error('SSE 请求失败:', err);
        this.flushAssistantText();
        this.handleSSEError(err);
      }
    });

    requestTask.onChunkReceived((res) => {
      try {
        this.handleSSEChunk(this.arrayBufferToString(res.data));
      } catch (e) {
        console.error('处理 chunk 失败:', e);
      }
    });
  },

  arrayBufferToString(buffer) {
    const arr = new Uint8Array(buffer);
    let str = '';

    for (let i = 0; i < arr.length; i++) {
      str += String.fromCharCode(arr[i]);
    }

    return decodeURIComponent(escape(str));
  },

  handleSSEChunk(chunk) {
    if (!chunk) return;

    const buffer = ((this.data.sseBuffer || '') + chunk).replace(/\r\n/g, '\n');
    const events = buffer.split('\n\n');
    const remain = events.pop() || '';

    this.setData({ sseBuffer: remain });
    events.forEach(eventText => this.handleSSEEvent(eventText));
  },

  flushSSEBuffer() {
    const buffer = this.data.sseBuffer;
    if (!buffer || !buffer.trim()) return;

    this.handleSSEEvent(buffer);
    this.setData({ sseBuffer: '' });
  },

  handleSSEEvent(eventText) {
    if (!eventText || !eventText.trim()) return;

    const lines = eventText.split('\n');
    let eventName = '';
    const dataLines = [];

    lines.forEach((line) => {
      if (line.indexOf('event:') === 0) {
        eventName = line.substring(6).trim();
      } else if (line.indexOf('data:') === 0) {
        dataLines.push(line.substring(5).trim());
      }
    });

    if (!dataLines.length) return;

    const dataStr = dataLines.join('\n');
    if (!dataStr || dataStr === '[DONE]') return;

    try {
      this.handleAgentData(eventName, JSON.parse(dataStr));
    } catch (e) {
      console.warn('SSE data JSON 解析失败:', dataStr);
    }
  },

  handleAgentData(eventName, data) {
    if (!data) return;

    const type = data.type || eventName || '';

    if (type === 'status' || type === 'thought' || type === 'token_stat') return;

    if (type === 'final' || eventName === 'final') {
      const content = data.content || '';
      if (!content) return;

      this.setData({ pendingFinalContent: (this.data.pendingFinalContent || '') + content });
      this.replaceThinkingPlaceholder();
      this.appendAssistantContentBuffered(content);
      return;
    }

    if (type === 'done' || eventName === 'done') {
      this.flushAssistantText();

      if (this.data.pendingFinalContent) {
        const reportJson = this.tryParseReportJson(this.data.pendingFinalContent);
        if (reportJson) this.handleParsedReport(reportJson);
      }

      this.setData({ pendingFinalContent: '', isTyping: false });
      this.saveChatHistory();
      return;
    }

    if (type === 'error' || eventName === 'error') {
      this.showAssistantError(data.message || data.error || '智能体处理失败');
      return;
    }

    if (type === 'reply') {
      const payload = data.payload || {};
      if (payload.is_from_self === true && payload.is_llm_generated === false) return;

      const content = payload.content || data.content || '';
      if (content) {
        this.replaceThinkingPlaceholder();
        this.appendAssistantContentBuffered(content);
      }
    }
  },

  replaceThinkingPlaceholder() {
    const messages = this.data.currentChatMessages;
    const lastIndex = messages.length - 1;
    const lastMsg = messages[lastIndex];

    if (lastMsg && lastMsg.role === 'assistant' && lastMsg.content === '正在分析，请稍等...') {
      const newMessages = [...messages];
      newMessages[lastIndex] = { ...newMessages[lastIndex], content: '' };
      this.setData({ currentChatMessages: newMessages, chatMessages: newMessages });
    }
  },

  appendAssistantContentBuffered(text) {
    if (!text) return;

    this.pendingAssistantText += text;
    if (this.flushTimer) return;

    this.flushTimer = setTimeout(() => {
      this.flushAssistantText();
    }, 200);
  },

  flushAssistantText() {
    const text = this.pendingAssistantText || '';
    this.pendingAssistantText = '';
    this.clearFlushTimer();

    if (!text) return;

    const messages = [...this.data.currentChatMessages];
    let index = messages.length - 1;

    if (!messages[index] || messages[index].role !== 'assistant') {
      messages.push({ role: 'assistant', content: '' });
      index = messages.length - 1;
    }

    messages[index] = {
      ...messages[index],
      content: (messages[index].content || '') + text
    };

    this.setData({ currentChatMessages: messages, chatMessages: messages });
    this.scrollToBottom();
  },

  clearFlushTimer() {
    if (this.flushTimer) {
      clearTimeout(this.flushTimer);
      this.flushTimer = null;
    }
  },

  handleSSEError(err) {
    const message = '请求失败：' + ((err && err.errMsg) || '未知错误');
    this.showAssistantError(message);
  },

  showAssistantError(message) {
    const messages = [...this.data.currentChatMessages];
    let index = messages.length - 1;

    if (!messages[index] || messages[index].role !== 'assistant') {
      messages.push({ role: 'assistant', content: '' });
      index = messages.length - 1;
    }

    messages[index] = {
      ...messages[index],
      content: messages[index].content === '正在分析，请稍等...'
        ? message
        : (messages[index].content || '') + '\n\n' + message
    };

    this.setData({
      currentChatMessages: messages,
      chatMessages: messages,
      isTyping: false
    });
    this.scrollToBottom();
  },

  tryParseReportJson(content) {
    if (!content || typeof content !== 'string') return null;

    const cleaned = content
      .replace(/^[\uFEFF\u200B\u200C\u200D\u2060]+/, '')
      .trim()
      .replace(/^```json\s*/i, '')
      .replace(/^```\s*/i, '')
      .replace(/```$/i, '')
      .trim();
    const jsonStr = this.extractFirstJsonObject(cleaned);

    if (!jsonStr) return null;

    try {
      const obj = JSON.parse(jsonStr);
      if (obj.title && (obj.sections || obj.locations)) return obj;
    } catch (e) {
      console.warn('JSON 解析失败:', e);
    }

    return null;
  },

  extractFirstJsonObject(text) {
    const start = text.indexOf('{');
    if (start === -1) return '';

    let depth = 0;
    let inString = false;
    let escape = false;

    for (let i = start; i < text.length; i++) {
      const ch = text[i];

      if (escape) {
        escape = false;
        continue;
      }

      if (ch === '\\') {
        escape = true;
        continue;
      }

      if (ch === '"') {
        inString = !inString;
        continue;
      }

      if (inString) continue;

      if (ch === '{') depth++;
      if (ch === '}') depth--;
      if (depth === 0) return text.slice(start, i + 1);
    }

    return '';
  },

  generateReportId() {
    return 'report_' + Date.now() + '_' + Math.random().toString(16).slice(2);
  },

  formatReportTime() {
    const now = new Date();
    const y = now.getFullYear();
    const m = String(now.getMonth() + 1).padStart(2, '0');
    const d = String(now.getDate()).padStart(2, '0');
    const h = String(now.getHours()).padStart(2, '0');
    const min = String(now.getMinutes()).padStart(2, '0');
    return `${y}-${m}-${d} ${h}:${min}`;
  },

  saveReportToStorage(reportJson) {
    if (!reportJson) return null;

    const reportId = this.generateReportId();
    const reportItem = {
      id: reportId,
      title: reportJson.title || '选址分析报告',
      summary: reportJson.summary || '',
      createdAt: this.formatReportTime(),
      data: reportJson
    };
    const reportHistory = wx.getStorageSync('reportHistory') || {};
    reportHistory[reportId] = reportItem;

    const keys = Object.keys(reportHistory).sort((a, b) => {
      const ta = reportHistory[a].createdAt || '';
      const tb = reportHistory[b].createdAt || '';
      return tb.localeCompare(ta);
    });

    keys.slice(30).forEach(id => {
      delete reportHistory[id];
    });

    wx.setStorageSync('reportHistory', reportHistory);
    wx.setStorageSync('latestReportId', reportId);
    wx.setStorageSync('latestReportData', reportJson);

    const appInstance = getApp();
    if (appInstance && appInstance.globalData) {
      appInstance.globalData.reportData = reportJson;
      appInstance.globalData.currentReportId = reportId;
    }

    return reportId;
  },

  handleParsedReport(reportJson) {
    const reportId = this.saveReportToStorage(reportJson);
    if (!reportId) return false;

    this.removeLastAssistantTextMessage();
    this.insertReportCard(reportJson.title, reportId);
    return true;
  },

  removeLastAssistantTextMessage() {
    const messages = [...this.data.currentChatMessages];
    const lastIndex = messages.length - 1;

    if (messages[lastIndex] && messages[lastIndex].role === 'assistant' && !messages[lastIndex].isReportCard) {
      messages.pop();
      this.setData({ currentChatMessages: messages, chatMessages: messages });
    }
  },

  insertReportCard(reportTitle, reportId) {
    const cardMessage = {
      role: 'assistant',
      isReportCard: true,
      reportId,
      reportTitle: reportTitle || '选址分析报告',
      content: `已生成报告《${reportTitle || '选址分析报告'}》`
    };

    this.setData({
      currentChatMessages: [...this.data.currentChatMessages, cardMessage],
      chatMessages: [...this.data.currentChatMessages, cardMessage]
    });
    this.scrollToBottom();
    this.saveChatHistory();
  },

  viewReport(e) {
    const dataset = e && e.currentTarget ? e.currentTarget.dataset : {};
    const reportId = dataset.reportId || dataset.reportid || '';
    let reportData = null;

    if (reportId) {
      const reportHistory = wx.getStorageSync('reportHistory') || {};
      const reportItem = reportHistory[reportId];

      if (reportItem && reportItem.data) {
        reportData = reportItem.data;
        wx.setStorageSync('latestReportId', reportId);
        wx.setStorageSync('latestReportData', reportData);
      }
    }

    if (!reportData) {
      const appInstance = getApp();
      reportData =
        (appInstance && appInstance.globalData && appInstance.globalData.reportData) ||
        wx.getStorageSync('latestReportData');
    }

    if (!reportData) {
      wx.showToast({ title: '报告数据缺失', icon: 'none' });
      return;
    }

    wx.navigateTo({ url: '/pages/report/report' });
  },

  onShareAppMessage() {
    return {
      title: '智汇铺手 - 智能选址助手',
      path: '/pages/index/index'
    };
  }
});
