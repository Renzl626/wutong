// pages/city-select/city-select.js
const amapFile = require('../../libs/amap-wx.130.js');

const AMAP_KEY = '270cacd2eeb9089758ccc278c5bba579';

// 热门城市
const HOT_CITIES = [
  '北京市', '上海市', '广州市', '深圳市',
  '杭州市', '南京市', '成都市', '武汉市',
  '西安市', '重庆市', '天津市', '苏州市',
  '郑州市', '长沙市', '青岛市', '沈阳市'
];

// 城市拼音映射
const CITY_PINYIN = {
  '北京市': 'bj', '上海市': 'sh', '广州市': 'gz', '深圳市': 'sz',
  '杭州市': 'hz', '南京市': 'nj', '成都市': 'cd', '武汉市': 'wh',
  '西安市': 'xa', '重庆市': 'cq', '天津市': 'tj', '苏州市': 'sz',
  '郑州市': 'zz', '长沙市': 'cs', '青岛市': 'qd', '沈阳市': 'sy',
  '哈尔滨市': 'heb', '合肥市': 'hf', '呼和浩特市': 'hhht',
  '大连市': 'dl', '昆明市': 'km', '济南市': 'jn', '福州市': 'fz',
  '厦门市': 'xm', '南昌市': 'nc', '南宁市': 'nn', '宁波市': 'nb',
  '石家庄市': 'sjz', '太原市': 'ty', '兰州市': 'lz', '无锡市': 'wx',
  '佛山市': 'fs', '东莞市': 'dg', '珠海市': 'zh', '中山市': 'zs',
  '温州市': 'wz', '金华市': 'jh', '嘉兴市': 'jx', '绍兴市': 'sx',
  '台州市': 'tz', '湖州市': 'huz', '丽水市': 'ls', '衢州市': 'qz',
  '舟山市': 'zs', '保定市': 'bd', '唐山市': 'ts', '廊坊市': 'lf',
  '沧州市': 'cz', '秦皇岛市': 'qhd', '邯郸市': 'hd', '邢台市': 'xt',
  '张家口市': 'zjk', '承德市': 'cd', '衡水市': 'hs', '大同市': 'dt',
  '阳泉市': 'yq', '长治市': 'cz', '晋城市': 'jc', '朔州市': 'shuoz',
  '晋中市': 'jz', '运城市': 'yc', '忻州市': 'xz', '临汾市': 'lf',
  '吕梁市': 'll', '鞍山市': 'as', '抚顺市': 'fs', '本溪市': 'bx',
  '丹东市': 'dd', '锦州市': 'jz', '营口市': 'yk', '阜新市': 'fx',
  '辽阳市': 'ly', '盘锦市': 'pj', '铁岭市': 'tl', '朝阳市': 'cy',
  '葫芦岛市': 'hld', '吉林市': 'jilin', '长春市': 'cc', '四平市': 'sp',
  '辽源市': 'ly', '通化市': 'th', '白山市': 'bs', '松原市': 'sys',
  '白城市': 'bc', '延边朝鲜族自治州': 'yb', '齐齐哈尔市': 'qqhe',
  '鸡西市': 'jx', '鹤岗市': 'hg', '双鸭山市': 'sys', '大庆市': 'dq',
  '伊春市': 'yc', '佳木斯市': 'jms', '七台河市': 'qth', '牡丹江市': 'mdj',
  '黑河市': 'hh', '绥化市': 'sh', '徐州市': 'xz', '连云港市': 'lyg',
  '淮安市': 'ha', '盐城市': 'yc', '扬州市': 'yz', '镇江市': 'zj',
  '泰州市': 'tz', '宿迁市': 'sq', '南通市': 'nt', '芜湖市': 'wh',
  '蚌埠市': 'bb', '淮南市': 'hn', '马鞍山市': 'mas', '淮北市': 'hb',
  '铜陵市': 'tl', '安庆市': 'aq', '黄山市': 'hs', '滁州市': 'cz',
  '阜阳市': 'fy', '宿州市': 'sz', '六安市': 'la', '亳州市': 'bz',
  '池州市': 'cz', '宣城市': 'xc', '莆田市': 'pt', '三明市': 'sm',
  '泉州市': 'qz', '漳州市': 'zz', '南平市': 'np', '龙岩市': 'ly',
  '宁德市': 'nd', '景德镇市': 'jdz', '萍乡市': 'px', '九江市': 'jj',
  '新余市': 'xy', '鹰潭市': 'yt', '赣州市': 'gz', '吉安市': 'ja',
  '宜春市': 'yc', '抚州市': 'fz', '上饶市': 'sr', '烟台市': 'yt',
  '威海市': 'wh', '潍坊市': 'wf', '淄博市': 'zb', '枣庄市': 'zz',
  '东营市': 'dy', '济宁市': 'jn', '泰安市': 'ta', '日照市': 'rz',
  '莱芜市': 'lw', '临沂市': 'ly', '德州市': 'dz', '聊城市': 'lc',
  '滨州市': 'bz', '菏泽市': 'hz', '开封市': 'kf', '洛阳市': 'ly',
  '平顶山市': 'pds', '安阳市': 'ay', '鹤壁市': 'hb', '新乡市': 'xx',
  '焦作市': 'jz', '濮阳市': 'py', '许昌市': 'xc', '漯河市': 'lh',
  '三门峡市': 'smx', '南阳市': 'ny', '商丘市': 'sq', '信阳市': 'xy',
  '周口市': 'zk', '驻马店市': 'zmd', '济源市': 'jy', '黄石市': 'hs',
  '十堰市': 'sy', '宜昌市': 'yc', '襄阳市': 'xy', '鄂州市': 'ez',
  '荆门市': 'jm', '孝感市': 'xg', '荆州市': 'jz', '黄冈市': 'hg',
  '咸宁市': 'xn', '随州市': 'sz', '恩施土家族苗族自治州': 'es',
  '仙桃市': 'xt', '潜江市': 'qj', '天门市': 'tm', '株洲市': 'zz',
  '湘潭市': 'xt', '衡阳市': 'hy', '岳阳市': 'yy', '常德市': 'cd',
  '张家界市': 'zjj', '益阳市': 'yy', '郴州市': 'cz', '永州市': 'yz',
  '怀化市': 'hh', '娄底市': 'ld', '韶关市': 'sg', '汕头市': 'st',
  '湛江市': 'zj', '江门市': 'jm', '茂名市': 'mm', '肇庆市': 'zq',
  '惠州市': 'hz', '梅州市': 'mz', '汕尾市': 'sw', '河源市': 'hy',
  '阳江市': 'yj', '清远市': 'qy', '潮州市': 'cz', '揭阳市': 'jy',
  '云浮市': 'yf', '柳州市': 'lz', '桂林市': 'gl', '梧州市': 'wz',
  '北海市': 'bh', '防城港市': 'fcg', '钦州市': 'qz', '贵港市': 'gg',
  '玉林市': 'yl', '百色市': 'bs', '贺州市': 'hz', '河池市': 'hc',
  '来宾市': 'lb', '崇左市': 'cz', '海口市': 'hk', '三亚市': 'sy',
  '儋州市': 'dz', '五指山市': 'wzs', '琼海市': 'qh', '文昌市': 'wc',
  '万宁市': 'wn', '东方市': 'df', '自贡市': 'zg', '攀枝花市': 'pzh',
  '泸州市': 'lz', '德阳市': 'dy', '广元市': 'gy', '遂宁市': 'sn',
  '内江市': 'nj', '乐山市': 'ls', '南充市': 'nc', '眉山市': 'ms',
  '宜宾市': 'yb', '广安市': 'ga', '达州市': 'dz', '雅安市': 'ya',
  '巴中市': 'bz', '资阳市': 'zy', '六盘水市': 'lps', '遵义市': 'zy',
  '安顺市': 'as', '毕节市': 'bj', '铜仁市': 'tr', '曲靖市': 'qj',
  '玉溪市': 'yx', '保山市': 'bs', '昭通市': 'zt', '丽江市': 'lj',
  '普洱市': 'pe', '临沧市': 'lc', '铜川市': 'tc', '宝鸡市': 'bj',
  '咸阳市': 'xy', '渭南市': 'wn', '延安市': 'ya', '汉中市': 'hz',
  '榆林市': 'yl', '安康市': 'ak', '商洛市': 'sl', '嘉峪关市': 'jyg',
  '金昌市': 'jc', '白银市': 'by', '天水市': 'ts', '武威市': 'ww',
  '张掖市': 'zy', '平凉市': 'pl', '酒泉市': 'jq', '庆阳市': 'qy',
  '定西市': 'dx', '陇南市': 'ln', '西宁市': 'xn', '海东市': 'hd',
  '银川市': 'yc', '石嘴山市': 'szs', '吴忠市': 'wz', '固原市': 'gy',
  '中卫市': 'zw', '乌鲁木齐市': 'wlq', '克拉玛依市': 'klmy',
  '吐鲁番市': 'tlp', '哈密市': 'hm'
};

// 全国主要城市（按字母排序）
const ALL_CITIES = {
  'A': ['阿拉善盟', '鞍山市', '安庆市', '安阳市', '阿坝藏族羌族自治州', '安顺市', '阿里地区', '阿克苏地区', '阿勒泰地区'],
  'B': ['北京市', '保定市', '包头市', '滨州市', '本溪市', '白城市', '蚌埠市', '巴彦淖尔市', '百色市', '北海市', '毕节市', '保山市', '白沙黎族自治县'],
  'C': ['重庆市', '成都市', '长春市', '长沙市', '沧州市', '承德市', '朝阳市', '常州市', '巢湖市', '池州市', '滁州市', '潮州市', '揭阳市'],
  'D': ['大连市', '大同市', '丹东市', '大庆市', '德州市', '东营市', '东莞市', '佛山市', '福州市', '定西市', '德宏傣族景颇族自治州'],
  'E': ['鄂尔多斯市', '恩施土家族苗族自治州', '鄂州市'],
  'F': ['抚顺市', '阜新市', '阜阳市', '抚州市'],
  'G': ['广州市', '贵阳市', '桂林市', '赣州市', '广元市', '固原市', '贵港市'],
  'H': ['哈尔滨市', '合肥市', '杭州市', '呼和浩特市', '邯郸市', '衡水市', '葫芦岛市', '淮北市', '淮南市', '黄山市', '怀化市', '惠州市', '河源市', '海口市', '红河哈尼族彝族自治州'],
  'J': ['济南市', '佳木斯市', '锦州市', '鸡西市', '荆州市', '焦作市', '济源市', '金华市', '嘉兴市', '江门市', '景德镇市', '九江市', '吉安市', '晋中市'],
  'K': ['昆明市', '开封市', '克拉玛依市', '喀什地区', '库尔勒市'],
  'L': ['兰州市', '洛阳市', '连云港市', '临沂市', '聊城市', '六安市', '丽水市', '龙岩市', '柳州市', '拉萨市', '六盘水市', '乐山市', '凉山彝族自治州', '辽源市', '辽阳市'],
  'M': ['牡丹江市', '绵阳市', '眉山市', '茂名市', '梅州市'],
  'N': ['南京市', '南宁市', '南通市', '宁波市', '南平市', '宁德市', '内江市', '南充市', '怒江傈僳族自治州'],
  'P': ['盘锦市', '平顶山市', '濮阳市', '莆田市', '萍乡市', '攀枝花市', '普洱市', '平凉市'],
  'Q': ['秦皇岛市', '齐齐哈尔市', '衢州市', '泉州市', '清远市', '钦州市', '黔南布依族苗族自治州', '黔东南苗族侗族自治州'],
  'R': ['日照市', '日喀则市'],
  'S': ['沈阳市', '石家庄市', '苏州市', '深圳市', '上海市', '三亚市', '汕头市', '韶关市', '绍兴市', '汕尾市', '朔州市', '三明市', '上饶市', '遂宁市'],
  'T': ['太原市', '唐山市', '泰安市', '台州市', '天津市', '铜陵市', '铁岭市', '通辽市', '天水市', '铜仁市', '塔城地区'],
  'W': ['武汉市', '无锡市', '威海市', '潍坊市', '温州市', '芜湖市', '吴忠市', '乌鲁木齐市', '武威市', '文山壮族苗族自治州', '文昌市'],
  'X': ['西安市', '徐州市', '襄阳市', '新乡市', '许昌市', '烟台市', '邢台市', '湘潭市', '咸阳市', '西双版纳傣族自治州', '西宁市', '忻州市'],
  'Y': ['烟台市', '扬州市', '宜昌市', '岳阳市', '益阳市', '运城市', '银川市', '盐城市', '雅安市', '宜宾市', '玉林市', '永州市', '榆林市', '延边朝鲜族自治州'],
  'Z': ['郑州市', '淄博市', '枣庄市', '珠海市', '湛江市', '肇庆市', '中山市', '张家口市', '驻马店市', '镇江市', '舟山市', '遵义市', '昭通市', '张掖市']
};

let searchTimer = null;

Page({
  data: {
    searchKeyword: '',
    currentCity: '',
    historyCities: [],
    hotCities: HOT_CITIES,
    cityGroups: [],
    letterList: Object.keys(ALL_CITIES),
    filteredCityGroups: [],
    searchResults: [],
    showSearchResults: false,
    hasSearchResults: true
  },

  onLoad() {
    this.amapPlugin = new amapFile.AMapWX({ key: AMAP_KEY });
    this.initCurrentCity();
    this.loadHistoryCities();
    this.initCityGroups();
  },

  initCurrentCity() {
    this.amapPlugin.getWxLocation(
      () => {},
      {
        fail: () => {
          wx.getLocation({
            type: 'gcj02',
            success: (res) => {
              this.getCityInfo(res.longitude, res.latitude);
            },
            fail: () => {
              this.setData({ currentCity: '定位失败' });
            }
          });
        },
        success: (location) => {
          const [longitude, latitude] = location.split(',');
          this.getCityInfo(parseFloat(longitude), parseFloat(latitude));
        }
      }
    );
  },

  getCityInfo(longitude, latitude) {
    this.amapPlugin.getRegeo({
      location: `${longitude},${latitude}`,
      success: (data) => {
        if (data && data.length > 0) {
          const city = data[0].regeocodeData.addressComponent.city || '未知城市';
          this.setData({ currentCity: city });
        }
      },
      fail: () => {
        this.setData({ currentCity: '获取城市失败' });
      }
    });
  },

  loadHistoryCities() {
    const history = wx.getStorageSync('cityHistory') || [];
    this.setData({ historyCities: history.slice(0, 5) });
  },

  initCityGroups() {
    const groups = Object.keys(ALL_CITIES).map(key => ({
      key: key,
      cities: ALL_CITIES[key]
    }));
    this.setData({ cityGroups: groups, filteredCityGroups: groups });
  },

  goBack() {
    wx.navigateBack();
  },

  onSearchInput(e) {
    const keyword = e.detail.value;
    this.setData({ searchKeyword: keyword });

    if (searchTimer) {
      clearTimeout(searchTimer);
    }

    if (!keyword) {
      this.setData({
        showSearchResults: false,
        searchResults: [],
        filteredCityGroups: this.data.cityGroups,
        hasSearchResults: true
      });
      return;
    }

    searchTimer = setTimeout(() => {
      this.performSearch(keyword);
    }, 300);
  },

  performSearch(keyword) {
    const allCities = [];
    Object.keys(ALL_CITIES).forEach(letter => {
      ALL_CITIES[letter].forEach(city => {
        allCities.push({ name: city, letter: letter });
      });
    });

    const lowerKeyword = keyword.toLowerCase();

    const matched = allCities.filter(item => {
      const cityName = item.name;
      const pinyin = CITY_PINYIN[cityName] || '';

      if (cityName.includes(keyword)) return true;
      if (pinyin && pinyin.includes(lowerKeyword)) return true;
      if (pinyin && pinyin.startsWith(lowerKeyword)) return true;

      return false;
    });

    if (matched.length === 0) {
      this.setData({
        showSearchResults: true,
        searchResults: [],
        hasSearchResults: false
      });
      return;
    }

    const results = matched.map(item => item.name);
    const uniqueResults = [...new Set(results)];

    this.setData({
      showSearchResults: true,
      searchResults: uniqueResults.slice(0, 20),
      hasSearchResults: uniqueResults.length > 0
    });
  },

  doSearch() {
    const keyword = this.data.searchKeyword.trim();
    if (!keyword) return;
    this.performSearch(keyword);
  },

  onSelectCity(e) {
    const city = e.currentTarget.dataset.city;
    if (!city) return;

    // 保存选择的城市到本地存储，作为双重保险
    wx.setStorageSync('selectedCity', city);

    const pages = getCurrentPages();
    const prevPage = pages[pages.length - 2];

    if (prevPage && prevPage.setData) {
      prevPage.setData({
        city: city
      });
    }

    const history = this.data.historyCities;
    const filtered = history.filter(c => c !== city);
    filtered.unshift(city);
    wx.setStorageSync('cityHistory', filtered.slice(0, 5));

    wx.showToast({
      title: `已选择: ${city}`,
      icon: 'none'
    });

    setTimeout(() => {
      wx.navigateBack();
    }, 800);
  },

  onUseCurrentCity() {
    const currentCity = this.data.currentCity;
    if (!currentCity || currentCity === '定位失败' || currentCity === '获取城市失败' || currentCity === '定位中...') {
      wx.showToast({
        title: '定位不可用，请手动选择',
        icon: 'none'
      });
      return;
    }
    this.onSelectCity({ currentTarget: { dataset: { city: currentCity } } });
  },

  scrollToLetter(e) {
    const letter = e.currentTarget.dataset.letter;
    wx.pageScrollTo({
      selector: `#city-${letter}`,
      duration: 300
    });
  },

  onShareAppMessage() {
    return {
      title: '智汇铺手 - 智能选址助手',
      path: '/pages/index/index'
    };
  }
});
