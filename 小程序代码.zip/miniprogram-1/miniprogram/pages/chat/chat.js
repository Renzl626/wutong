// pages/chat/chat.js
const app = getApp();

const DEBUG = false;

Page({
  data: {
    inputValue: '',
    messages: [],
    loading: false,
    isStreaming: false,
    scrollIntoView: '',
    sessionId: '',
    sseBuffer: ''
  },

  // 缓冲区：减少频繁 setData
  pendingAssistantText: '',
  flushTimer: null,

  // SSE 请求控制
  requestTask: null,
  sseFinished: false,
  lastFinalContent: '',

  onLoad() {
    let sessionId = wx.getStorageSync('session_id');

    if (!sessionId) {
      if (app && typeof app.generateUUID === 'function') {
        sessionId = app.generateUUID();
      } else {
        sessionId =
          'wx_' + Date.now() + '_' + Math.random().toString(16).slice(2);
      }

      wx.setStorageSync('session_id', sessionId);
    }

    this.setData({
      sessionId,
      messages: [
        {
          role: 'assistant',
          content: '你好!我是智能选址助手,请问你想了解哪个位置的商铺?'
        }
      ]
    });

    if (DEBUG) {
      console.log('当前 sessionId:', sessionId);
    }
  },

  onUnload() {
    this.clearFlushTimer();

    this.sseFinished = true;

    if (this.requestTask && typeof this.requestTask.abort === 'function') {
      try {
        this.requestTask.abort();
      } catch (e) {
        if (DEBUG) {
          console.warn('onUnload abort failed:', e);
        }
      }
    }

    this.requestTask = null;
  },

  onInput(e) {
    this.setData({
      inputValue: e.detail.value
    });
  },

  async sendMessage() {
    const text = (this.data.inputValue || '').trim();

    if (!text) {
      return;
    }

    if (this.data.loading || this.data.isStreaming) {
      wx.showToast({
        title: '正在分析中,请稍候',
        icon: 'none'
      });
      return;
    }

    const userMsg = {
      role: 'user',
      content: text
    };

    const assistantMsg = {
      role: 'assistant',
      content: '正在分析,请稍候...'
    };

    this.pendingAssistantText = '';
    this.clearFlushTimer();
    this.lastFinalContent = '';

    this.setData({
      messages: this.data.messages.concat([userMsg, assistantMsg]),
      inputValue: '',
      loading: true,
      isStreaming: true,
      sseBuffer: ''
    });

    this.scrollToBottom();

    try {
      await this.startSSE(text);
    } catch (e) {
      if (DEBUG) {
        console.error('sendMessage error:', e);
      }
    }
  },

  startSSE(userMessage) {
    const that = this;
    const url = 'https://api.mzhyui.cn/chat';
    const sessionId = this.data.sessionId || ('wx_' + Date.now());

    if (DEBUG) {
      console.log('准备发起 SSE 请求:', {
        url,
        message: userMessage,
        sessionId
      });
    }

    // 如果上一次还没结束，先关掉
    if (this.requestTask && typeof this.requestTask.abort === 'function') {
      try {
        this.requestTask.abort();
      } catch (e) {
        if (DEBUG) console.warn('abort old request failed:', e);
      }
    }

    this.sseFinished = false;
    this.requestTask = null;

    return new Promise((resolve, reject) => {
      const requestTask = wx.request({
        url,
        method: 'POST',
        data: {
          message: userMessage,
          sessionId
        },
        header: {
          'content-type': 'application/json',
          Accept: 'text/event-stream'
        },
        enableChunked: true,
        timeout: 300000,

        success(res) {
          if (DEBUG) {
            console.log('SSE 请求 success:', res);
          }

          if (that.sseFinished) {
            return;
          }

          that.clearFlushTimer();
          that.flushAssistantText();

          that.sseFinished = true;
          that.setData({
            loading: false,
            isStreaming: false,
            sseBuffer: ''
          });

          that.requestTask = null;
          resolve(res);
        },

        fail(err) {
          // 如果是主动 abort，忽略
          if (that.sseFinished) {
            if (DEBUG) {
              console.log('SSE 已结束，忽略 fail:', err);
            }
            return;
          }

          console.error('SSE 请求失败:', err);

          that.sseFinished = true;
          that.clearFlushTimer();
          that.flushAssistantText();

          const messages = that.data.messages || [];
          const lastIndex = messages.length - 1;
          const lastMsg = messages[lastIndex];

          if (lastMsg && lastMsg.role === 'assistant') {
            const oldContent = lastMsg.content || '';
            if (!oldContent || oldContent === '正在分析,请稍候...') {
              that.setData({
                [`messages[${lastIndex}].content`]:
                  '请求失败:' + ((err && err.errMsg) || '未知错误'),
                loading: false,
                isStreaming: false,
                sseBuffer: ''
              });
            } else {
              that.setData({
                loading: false,
                isStreaming: false,
                sseBuffer: ''
              });
            }
          } else {
            that.setData({
              loading: false,
              isStreaming: false,
              sseBuffer: ''
            });
          }

          that.requestTask = null;
          reject(err);
        }
      });

      that.requestTask = requestTask;

      requestTask.onChunkReceived(function (res) {
        try {
          const chunk = that.arrayBufferToString(res.data);

          if (DEBUG) {
            console.log('收到 chunk 长度:', chunk.length);
            console.log('收到 chunk 前 200 字:', chunk.slice(0, 200));
          }

          that.handleSSEChunk(chunk);
        } catch (e) {
          console.error('处理 chunk 失败:', e);
        }
      });
    });
  },

  // 处理 chunk：只保留完整 SSE 事件
  handleSSEChunk(chunk) {
    if (!chunk) return;

    let buffer = (this.data.sseBuffer || '') + chunk;
    buffer = buffer.replace(/\r\n/g, '\n');

    const parts = buffer.split('\n\n');
    const remain = parts.pop() || '';

    this.setData({
      sseBuffer: remain
    });

    for (const part of parts) {
      this.handleSSEEvent(part);
    }
  },

  // 解析单个 SSE 事件
  handleSSEEvent(eventText) {
    if (!eventText || !eventText.trim()) return;

    const lines = eventText.split('\n');
    let eventName = '';
    const dataLines = [];

    for (const line of lines) {
      if (line.indexOf('event:') === 0) {
        eventName = line.substring(6).trim();
      } else if (line.indexOf('data:') === 0) {
        dataLines.push(line.substring(5).trim());
      }
    }

    if (dataLines.length === 0) {
      return;
    }

    const dataStr = dataLines.join('\n');
    if (!dataStr || dataStr === '[DONE]') {
      return;
    }

    let data;
    try {
      data = JSON.parse(dataStr);
    } catch (e) {
      if (DEBUG) {
        console.warn('SSE JSON 解析失败:', dataStr);
      }
      return;
    }

    this.handleAgentData(eventName, data);
  },

  handleAgentData(eventName, data) {
    if (!data) return;

    const type = data.type || eventName || '';

    if (DEBUG) {
      console.log('处理事件:', eventName, data);
    }

    if (type === 'status' || eventName === 'status') {
      return;
    }

    if (type === 'final' || eventName === 'final') {
      const content = data.content || '';
      if (!content) return;

      // 如果后端返回的是“累计全文”，就只追加新增部分
      let delta = content;
      if (this.lastFinalContent && content.startsWith(this.lastFinalContent)) {
        delta = content.slice(this.lastFinalContent.length);
      }

      this.lastFinalContent = content;

      if (delta) {
        this.replaceThinkingPlaceholderIfNeeded();
        this.appendAssistantContentBuffered(delta);
      }
      return;
    }

    if (type === 'error' || eventName === 'error') {
      const message = data.message || data.error || '智能体处理失败';
      this.showAssistantError(message);
      this.finishStreaming();
      return;
    }

    if (type === 'done' || eventName === 'done') {
      this.clearFlushTimer();
      this.flushAssistantText();
      this.finishStreaming();
      return;
    }

    if (type === 'thought' || type === 'token_stat') {
      return;
    }

    if (type === 'reply') {
      const payload = data.payload || {};
      if (
        payload.is_from_self === true &&
        payload.is_llm_generated === false
      ) {
        return;
      }

      const content = payload.content || data.content || '';
      if (content) {
        this.replaceThinkingPlaceholderIfNeeded();
        this.appendAssistantContentBuffered(content);
      }
    }
  },

  finishStreaming() {
    if (this.sseFinished) {
      this.setData({
        loading: false,
        isStreaming: false
      });
      return;
    }

    this.sseFinished = true;

    this.setData({
      loading: false,
      isStreaming: false,
      sseBuffer: ''
    });

    if (this.requestTask && typeof this.requestTask.abort === 'function') {
      try {
        this.requestTask.abort();
      } catch (e) {
        if (DEBUG) {
          console.warn('abort failed:', e);
        }
      }
    }

    this.requestTask = null;
  },

  replaceThinkingPlaceholderIfNeeded() {
    const messages = this.data.messages || [];
    const lastIndex = messages.length - 1;
    const lastMsg = messages[lastIndex];

    if (
      lastMsg &&
      lastMsg.role === 'assistant' &&
      lastMsg.content === '正在分析,请稍候...'
    ) {
      this.setData({
        [`messages[${lastIndex}].content`]: ''
      });
    }
  },

  appendAssistantContentBuffered(text) {
    if (!text) return;

    this.pendingAssistantText += text;

    if (this.flushTimer) {
      return;
    }

    this.flushTimer = setTimeout(() => {
      this.flushAssistantText();
    }, 100);
  },

  flushAssistantText() {
    const text = this.pendingAssistantText || '';
    this.pendingAssistantText = '';
    this.clearFlushTimer();

    if (!text) {
      return;
    }

    const messages = this.data.messages || [];
    let index = messages.length - 1;

    if (!messages[index] || messages[index].role !== 'assistant') {
      messages.push({
        role: 'assistant',
        content: ''
      });
      this.setData({
        messages
      });
      index = messages.length - 1;
    }

    const oldContent = messages[index].content || '';
    const newContent = oldContent + text;

    this.setData({
      [`messages[${index}].content`]: newContent
    });

    this.scrollToBottom();
  },

  clearFlushTimer() {
    if (this.flushTimer) {
      clearTimeout(this.flushTimer);
      this.flushTimer = null;
    }
  },

  showAssistantError(message) {
    const messages = this.data.messages || [];
    let index = messages.length - 1;

    if (!messages[index] || messages[index].role !== 'assistant') {
      messages.push({
        role: 'assistant',
        content: ''
      });

      this.setData({
        messages
      });

      index = messages.length - 1;
    }

    const oldContent = messages[index].content || '';

    this.setData({
      [`messages[${index}].content`]:
        oldContent && oldContent !== '正在分析,请稍候...'
          ? oldContent + '\n\n错误:' + message
          : '错误:' + message,
      loading: false,
      isStreaming: false
    });

    this.scrollToBottom();
  },

  arrayBufferToString(buffer) {
    if (!buffer) return '';

    try {
      if (typeof TextDecoder !== 'undefined') {
        const decoder = new TextDecoder('utf-8');
        return decoder.decode(new Uint8Array(buffer));
      }
    } catch (e) {
      if (DEBUG) {
        console.warn('TextDecoder 解码失败:', e);
      }
    }

    const uint8Array = new Uint8Array(buffer);
    let encodedString = '';

    for (let i = 0; i < uint8Array.length; i++) {
      encodedString += String.fromCharCode(uint8Array[i]);
    }

    try {
      return decodeURIComponent(escape(encodedString));
    } catch (e) {
      return encodedString;
    }
  },

  scrollToBottom() {
    setTimeout(() => {
      this.setData({
        scrollIntoView: 'bottom-marker'
      });
    }, 100);
  }
});