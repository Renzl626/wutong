// pages/report/report.js

Page({
  data: {
    report: null,
    locations: [],
    analysisBlocks: [],
    loading: true,
    errorMessage: ''
  },

  onLoad(options) {
    this.loadReport(options);
  },

  onShow() {
    // 如果从历史报告卡片再次进入，确保读取的是最新写入的 latestReportData
    if (!this.data.report) {
      this.loadReport({});
    }
  },

  loadReport(options) {
    let reportData = null;

    // 1. 兼容旧逻辑：如果 URL 里仍然传了 data，也能读取
    if (options && options.data) {
      try {
        const decoded = decodeURIComponent(options.data);
        reportData = JSON.parse(decoded);
      } catch (e) {
        console.warn('URL 报告数据解析失败:', e);
      }
    }

    // 2. 优先读取当前报告数据
    if (!reportData) {
      reportData = wx.getStorageSync('latestReportData');
    }

    // 3. 如果 latestReportData 不存在，用 latestReportId 去 reportHistory 找
    if (!reportData) {
      const latestReportId = wx.getStorageSync('latestReportId');
      const reportHistory = wx.getStorageSync('reportHistory') || {};

      if (latestReportId && reportHistory[latestReportId] && reportHistory[latestReportId].data) {
        reportData = reportHistory[latestReportId].data;
      }
    }

    // 4. 最后兜底读取 globalData
    if (!reportData) {
      const app = getApp();
      if (app && app.globalData && app.globalData.reportData) {
        reportData = app.globalData.reportData;
      }
    }

    if (!reportData) {
      this.setData({
        report: null,
        locations: [],
        analysisBlocks: [],
        loading: false,
        errorMessage: '暂无报告数据'
      });

      wx.showToast({
        title: '暂无报告数据',
        icon: 'none'
      });

      return;
    }

    const normalizedReport = this.normalizeReport(reportData);

    this.setData({
      report: normalizedReport,
      locations: normalizedReport.locations,
      analysisBlocks: this.parseMarkdownLikeText(normalizedReport.detailedAnalysis),
      loading: false,
      errorMessage: ''
    });

    // 写回缓存，保证刷新或返回后仍然能打开
    wx.setStorageSync('latestReportData', normalizedReport);
  },

  normalizeReport(report) {
    const safeReport = report || {};

    const rawLocations = Array.isArray(safeReport.locations)
      ? safeReport.locations
      : [];

    const locations = rawLocations.map((location, index) => {
      const scoreBreakdown = location.scoreBreakdown || {};
      const scoreItems = Object.keys(scoreBreakdown).map((key) => {
        return {
          name: key,
          score: this.toSafeScore(scoreBreakdown[key]),
          percent: this.toSafePercent(scoreBreakdown[key])
        };
      });

      const totalScore = this.toSafeScore(location.totalScore);

      return {
        id: index,
        name: location.name || '未命名位置',
        address: location.address || '暂无详细地址',
        totalScore,
        totalPercent: this.toSafePercent(totalScore),
        scoreBreakdown,
        scoreItems,
        advantages: Array.isArray(location.advantages) ? location.advantages : [],
        risks: Array.isArray(location.risks) ? location.risks : [],
        recommendation: location.recommendation || '谨慎选择',
        recommendationClass: this.getRecommendationClass(location.recommendation)
      };
    });

    const comparisonTable = safeReport.comparisonTable || {};
    const finalRecommendation = safeReport.finalRecommendation || {};

    return {
      title: safeReport.title || '选址分析报告',
      summary: safeReport.summary || '暂无摘要',
      locations,
      comparisonTable: {
        headers: Array.isArray(comparisonTable.headers) ? comparisonTable.headers : [],
        rows: Array.isArray(comparisonTable.rows) ? comparisonTable.rows : []
      },
      finalRecommendation: {
        firstChoice: finalRecommendation.firstChoice || '',
        firstReason: finalRecommendation.firstReason || '',
        secondChoice: finalRecommendation.secondChoice || '',
        secondReason: finalRecommendation.secondReason || '',
        cautiousChoice: finalRecommendation.cautiousChoice || '',
        cautiousReason: finalRecommendation.cautiousReason || ''
      },
      detailedAnalysis: safeReport.detailedAnalysis || ''
    };
  },

  toSafeScore(value) {
    const num = Number(value);
    if (isNaN(num)) return 0;
    if (num < 0) return 0;
    if (num > 100) return 100;
    return Math.round(num);
  },

  toSafePercent(value) {
    return this.toSafeScore(value);
  },

  getRecommendationClass(recommendation) {
    if (recommendation === '首选') return 'first';
    if (recommendation === '次选') return 'second';
    return 'cautious';
  },

  parseMarkdownLikeText(text) {
    if (!text || typeof text !== 'string') {
      return [];
    }

    const lines = text.replace(/\r\n/g, '\n').split('\n');
    const blocks = [];
    let paragraph = [];

    const flushParagraph = () => {
      const content = paragraph.join('\n').trim();
      if (content) {
        blocks.push({
          type: 'paragraph',
          content
        });
      }
      paragraph = [];
    };

    const isTableLine = (line) => {
      const trimmed = line.trim();
      return trimmed.startsWith('|') && trimmed.endsWith('|') && trimmed.length > 2;
    };

    const isSeparatorLine = (line) => {
      const trimmed = line.trim();
      return /^\|[\s\-:|]+\|$/.test(trimmed) && trimmed.indexOf('-') !== -1;
    };

    let i = 0;

    while (i < lines.length) {
      const rawLine = lines[i];
      const line = rawLine.trim();

      if (!line) {
        flushParagraph();
        i++;
        continue;
      }

      if (isTableLine(line)) {
        flushParagraph();

        const tableLines = [];

        while (i < lines.length && isTableLine(lines[i])) {
          tableLines.push(lines[i].trim());
          i++;
        }

        if (tableLines.length >= 2 && tableLines.some(isSeparatorLine)) {
          const headers = tableLines[0]
            .split('|')
            .filter(cell => cell.trim() !== '')
            .map(cell => cell.trim());

          const separatorIndex = tableLines.findIndex(isSeparatorLine);
          const rows = [];

          for (let rowIndex = separatorIndex + 1; rowIndex < tableLines.length; rowIndex++) {
            const row = tableLines[rowIndex]
              .split('|')
              .filter(cell => cell.trim() !== '')
              .map(cell => cell.trim());

            const filledRow = row.slice();

            while (filledRow.length < headers.length) {
              filledRow.push('');
            }

            rows.push(filledRow.slice(0, headers.length));
          }

          blocks.push({
            type: 'table',
            headers,
            rows
          });
        } else {
          blocks.push({
            type: 'paragraph',
            content: tableLines.join('\n')
          });
        }

        continue;
      }

      if (line.startsWith('### ')) {
        flushParagraph();
        blocks.push({
          type: 'heading3',
          content: line.replace(/^###\s+/, '')
        });
        i++;
        continue;
      }

      if (line.startsWith('## ')) {
        flushParagraph();
        blocks.push({
          type: 'heading2',
          content: line.replace(/^##\s+/, '')
        });
        i++;
        continue;
      }

      if (line.startsWith('# ')) {
        flushParagraph();
        blocks.push({
          type: 'heading1',
          content: line.replace(/^#\s+/, '')
        });
        i++;
        continue;
      }

      if (line.startsWith('- ') || line.startsWith('* ') || /^(\d+)\.\s+/.test(line)) {
        flushParagraph();

        const items = [];

        while (i < lines.length) {
          const listLine = lines[i].trim();

          if (
            listLine.startsWith('- ') ||
            listLine.startsWith('* ') ||
            /^(\d+)\.\s+/.test(listLine)
          ) {
            items.push(
              listLine
                .replace(/^- /, '')
                .replace(/^\* /, '')
                .replace(/^(\d+)\.\s+/, '')
            );
            i++;
          } else {
            break;
          }
        }

        blocks.push({
          type: 'list',
          items
        });

        continue;
      }

      paragraph.push(rawLine);
      i++;
    }

    flushParagraph();

    return blocks;
  },

  goBack() {
    wx.navigateBack({
      fail() {
        wx.switchTab({
          url: '/pages/index/index'
        });
      }
    });
  },

  copySummary() {
    const report = this.data.report;

    if (!report) {
      wx.showToast({
        title: '暂无报告',
        icon: 'none'
      });
      return;
    }

    const text = `${report.title}\n\n${report.summary}`;

    wx.setClipboardData({
      data: text,
      success() {
        wx.showToast({
          title: '已复制摘要',
          icon: 'success'
        });
      }
    });
  },

  copyFullReport() {
    const report = this.data.report;

    if (!report) {
      wx.showToast({
        title: '暂无报告',
        icon: 'none'
      });
      return;
    }

    let text = `${report.title}\n\n${report.summary}\n\n`;

    if (report.locations && report.locations.length) {
      text += '【候选点位分析】\n';

      report.locations.forEach((location, index) => {
        text += `${index + 1}. ${location.name}\n`;
        text += `地址：${location.address}\n`;
        text += `总分：${location.totalScore}\n`;
        text += `推荐等级：${location.recommendation}\n`;

        if (location.scoreItems && location.scoreItems.length) {
          text += '分项评分：';
          text += location.scoreItems
            .map(item => `${item.name}${item.score}`)
            .join('，');
          text += '\n';
        }

        if (location.advantages && location.advantages.length) {
          text += `优势：${location.advantages.join('；')}\n`;
        }

        if (location.risks && location.risks.length) {
          text += `风险：${location.risks.join('；')}\n`;
        }

        text += '\n';
      });
    }

    const finalRecommendation = report.finalRecommendation || {};

    if (
      finalRecommendation.firstChoice ||
      finalRecommendation.secondChoice ||
      finalRecommendation.cautiousChoice
    ) {
      text += '【最终推荐】\n';

      if (finalRecommendation.firstChoice) {
        text += `首选：${finalRecommendation.firstChoice}\n`;
        text += `${finalRecommendation.firstReason}\n\n`;
      }

      if (finalRecommendation.secondChoice) {
        text += `次选：${finalRecommendation.secondChoice}\n`;
        text += `${finalRecommendation.secondReason}\n\n`;
      }

      if (finalRecommendation.cautiousChoice) {
        text += `谨慎选择：${finalRecommendation.cautiousChoice}\n`;
        text += `${finalRecommendation.cautiousReason}\n\n`;
      }
    }

    if (report.detailedAnalysis) {
      text += `【详细分析】\n${report.detailedAnalysis}`;
    }

    wx.setClipboardData({
      data: text,
      success() {
        wx.showToast({
          title: '已复制报告',
          icon: 'success'
        });
      }
    });
  }
});