// pages/mine/mine.js
Page({
  data: {
    userInfo: null,
    hasLogin: false
  },

  onLoad() {
    this.checkLoginStatus();
  },

  onShow() {
    if (typeof this.getTabBar === 'function' && this.getTabBar()) {
      this.getTabBar().setData({
        selected: 1
      });
    }
  },

  checkLoginStatus() {
    const userInfo = wx.getStorageSync('userInfo');
    if (userInfo) {
      this.setData({
        userInfo,
        hasLogin: true
      });
    }
  },

  goToLogin() {
    wx.showModal({
      title: '提示',
      content: '登录后可享受更多服务',
      confirmText: '去登录',
      cancelText: '取消',
      success: (res) => {
        if (res.confirm) {
          wx.showToast({
            title: '登录功能开发中',
            icon: 'none'
          });
        }
      }
    });
  },

  goToCustom() {
    wx.showToast({
      title: '定制服务开发中',
      icon: 'none'
    });
  },

  goToFeedback() {
    wx.showToast({
      title: '反馈中心开发中',
      icon: 'none'
    });
  },

  goToAbout() {
    wx.showModal({
      title: '关于智汇铺手',
      content: '智汇铺手是一款基于人工智能、数据融合与多智能体协同决策技术的商铺选址平台，为您提供科学、自动化且可解释的选址方案。',
      showCancel: false,
      confirmText: '我知道了'
    });
  },

  onShareAppMessage() {
    return {
      title: '智汇铺手 - 智能选址助手',
      path: '/pages/index/index'
    };
  }
});