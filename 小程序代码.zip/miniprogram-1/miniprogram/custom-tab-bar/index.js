Component({
  data: {
    selected: 0,
    list: [
      {
        pagePath: '/pages/index/index',
        text: '选址'
      },
      {
        pagePath: '/pages/mine/mine',
        text: '我的'
      }
    ]
  },

  methods: {
    switchTab(e) {
      const index = e.currentTarget.dataset.index;
      const url = this.data.list[index].pagePath;

      this.setData({ selected: index });
      wx.switchTab({ url });
    }
  }
});
