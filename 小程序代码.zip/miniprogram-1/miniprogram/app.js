App({
  onLaunch() {
    // 初始化会话ID（存储在全局，也可存在 storage）
    if (!wx.getStorageSync('session_id')) {
      wx.setStorageSync('session_id', this.generateUUID());
    }
  },
  globalData: {
    reportData: null
  },
  generateUUID() {
    return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, c => {
      const r = Math.random() * 16 | 0;
      const v = c === 'x' ? r : (r & 0x3 | 0x8);
      return v.toString(16);
    });
  }
});