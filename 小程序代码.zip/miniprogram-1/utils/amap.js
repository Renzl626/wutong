/**
 * 高德地图 Web 服务封装
 * 适用于微信小程序前端直连调用
 * 注意：正式项目建议通过云函数或后端代理，避免 Key 暴露
 */

const AMAP_KEY = '270cacd2eeb9089758ccc278c5bba579';
const AMAP_BASE_URL = 'https://restapi.amap.com';

/**
 * 通用请求封装
 * @param {string} url
 * @param {Object} data
 * @returns {Promise<Object>}
 */
function request(url, data = {}) {
  return new Promise((resolve, reject) => {
    wx.request({
      url,
      method: 'GET',
      data,
      success(res) {
        const data = res.data || {};

        // 高德接口正常返回通常会有 status=1
        if (data.status === '1' || data.status === 1) {
          resolve(data);
        } else {
          reject({
            message: data.info || '高德接口请求失败',
            infocode: data.infocode,
            raw: data
          });
        }
      },
      fail(err) {
        reject({
          message: '网络请求失败',
          raw: err
        });
      }
    });
  });
}

/**
 * 地址转经纬度
 * @param {string} address 详细地址
 * @param {string} city 城市，可选
 * @returns {Promise<Object>}
 */
function geocode(address, city = '') {
  if (!address) {
    return Promise.reject({
      message: 'address 不能为空'
    });
  }

  return request(`${AMAP_BASE_URL}/v3/geocode/geo`, {
    key: AMAP_KEY,
    address,
    city
  });
}

/**
 * 经纬度转地址
 * @param {string} location 经纬度，格式：lng,lat
 * @param {string} radius 位置附近范围，默认1000米
 * @returns {Promise<Object>}
 */
function regeo(location, radius = 1000) {
  if (!location) {
    return Promise.reject({
      message: 'location 不能为空'
    });
  }

  return request(`${AMAP_BASE_URL}/v3/geocode/regeo`, {
    key: AMAP_KEY,
    location,
    radius,
    extensions: 'all',
    batch: false,
    roadlevel: 0
  });
}

/**
 * 周边 POI 搜索
 * @param {string} location 经纬度，格式：lng,lat
 * @param {Object} options
 * @returns {Promise<Object>}
 */
function aroundPOI(location, options = {}) {
  if (!location) {
    return Promise.reject({
      message: 'location 不能为空'
    });
  }

  const {
    keywords = '',
    types = '',
    radius = 1000,
    page = 1,
    offset = 20,
    sortrule = 'distance',
    citylimit = false
  } = options;

  return request(`${AMAP_BASE_URL}/v3/place/around`, {
    key: AMAP_KEY,
    location,
    keywords,
    types,
    radius,
    page,
    offset,
    sortrule,
    citylimit,
    extensions: 'base'
  });
}

/**
 * 关键词 POI 搜索
 * @param {string} keywords 关键词
 * @param {Object} options
 * @returns {Promise<Object>}
 */
function searchPOI(keywords, options = {}) {
  if (!keywords) {
    return Promise.reject({
      message: 'keywords 不能为空'
    });
  }

  const {
    city = '',
    types = '',
    page = 1,
    offset = 20,
    citylimit = false,
    children = 1
  } = options;

  return request(`${AMAP_BASE_URL}/v3/place/text`, {
    key: AMAP_KEY,
    keywords,
    city,
    types,
    page,
    offset,
    citylimit,
    children,
    extensions: 'base'
  });
}

/**
 * 驾车路径规划
 * @param {string} origin 起点经纬度，格式：lng,lat
 * @param {string} destination 终点经纬度，格式：lng,lat
 * @param {Object} options
 * @returns {Promise<Object>}
 */
function driving(origin, destination, options = {}) {
  if (!origin || !destination) {
    return Promise.reject({
      message: 'origin 和 destination 不能为空'
    });
  }

  const {
    strategy = 0,
    avoidpolygons = '',
    avoidroad = ''
  } = options;

  return request(`${AMAP_BASE_URL}/v3/direction/driving`, {
    key: AMAP_KEY,
    origin,
    destination,
    strategy,
    avoidpolygons,
    avoidroad
  });
}

/**
 * 公交路径规划
 * @param {string} origin 起点经纬度，格式：lng,lat
 * @param {string} destination 终点经纬度，格式：lng,lat
 * @param {Object} options
 * @returns {Promise<Object>}
 */
function transit(origin, destination, options = {}) {
  if (!origin || !destination) {
    return Promise.reject({
      message: 'origin 和 destination 不能为空'
    });
  }

  const {
    city = '',
    strategy = 0,
    nightflag = 0
  } = options;

  return request(`${AMAP_BASE_URL}/v3/direction/transit/integrated`, {
    key: AMAP_KEY,
    origin,
    destination,
    city,
    strategy,
    nightflag
  });
}

/**
 * 获取关键 POI 概览数据
 * 用于你的选址分析：学校、地铁、商场、餐饮、竞品等
 * @param {string} location 经纬度，格式：lng,lat
 * @param {number} radius 半径，默认1000米
 * @returns {Promise<Object>}
 */
async function getSiteAnalysisData(location, radius = 1000) {
  try {
    const poiTypes = [
      { label: '餐饮', types: '050000' },
      { label: '购物', types: '060000' },
      { label: '教育', types: '141200' },
      { label: '交通', types: '150500' },
      { label: '生活服务', types: '070000' }
    ];

    const results = await Promise.all(
      poiTypes.map(item =>
        aroundPOI(location, {
          types: item.types,
          radius,
          offset: 20,
          page: 1,
          sortrule: 'distance'
        }).then(res => ({
          label: item.label,
          count: Number(res.count || 0),
          pois: res.pois || []
        })).catch(() => ({
          label: item.label,
          count: 0,
          pois: []
        }))
      )
    );

    return {
      location,
      radius,
      summary: results,
      totalCount: results.reduce((sum, item) => sum + (item.count || 0), 0)
    };
  } catch (err) {
    return {
      location,
      radius,
      summary: [],
      totalCount: 0,
      error: err
    };
  }
}

/**
 * 将高德 POI 数据整理成更适合业务分析的格式
 * @param {Object} poiResult 高德返回结果
 * @returns {Array}
 */
function normalizePOIs(poiResult) {
  const pois = poiResult && poiResult.pois ? poiResult.pois : [];
  return pois.map(item => ({
    id: item.id,
    name: item.name,
    type: item.type || '',
    typecode: item.typecode || '',
    address: item.address || '',
    location: item.location || '',
    distance: item.distance ? Number(item.distance) : null,
    tel: item.tel || '',
    pname: item.pname || '',
    cityname: item.cityname || '',
    adname: item.adname || ''
  }));
}

/**
 * 根据地址获取地点基础信息
 * @param {string} address
 * @param {string} city
 * @returns {Promise<Object>}
 */
async function getLocationInfo(address, city = '') {
  const geo = await geocode(address, city);
  const first = geo.geocodes && geo.geocodes[0];

  if (!first) {
    throw {
      message: '未找到该地址对应的经纬度',
      raw: geo
    };
  }

  return {
    address,
    city,
    location: first.location,
    formattedAddress: first.formatted_address || '',
    province: first.province || '',
    cityname: first.city || '',
    district: first.district || '',
    level: first.level || ''
  };
}

module.exports = {
  AMAP_KEY,
  geocode,
  regeo,
  aroundPOI,
  searchPOI,
  driving,
  transit,
  getSiteAnalysisData,
  normalizePOIs,
  getLocationInfo
};
