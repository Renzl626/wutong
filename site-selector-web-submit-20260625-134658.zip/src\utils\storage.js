export const storage = {
  get(key, defaultValue = null) {
    const value = localStorage.getItem(key)
    if (value === null || value === undefined) return defaultValue
    try {
      return JSON.parse(value)
    } catch {
      return value
    }
  },

  set(key, value) {
    localStorage.setItem(key, JSON.stringify(value))
  },

  remove(key) {
    localStorage.removeItem(key)
  }
}