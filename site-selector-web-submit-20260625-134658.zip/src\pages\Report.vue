<template>
  <div class="report-page">
    <div class="ambient-grid"></div>

    <div v-if="loading" class="state-page">
      <div class="loader"></div>
      <p>正在加载选址报告...</p>
    </div>

    <div v-else-if="!report" class="state-page">
      <div class="empty-mark">SITE</div>
      <h1>暂无报告数据</h1>
      <button class="primary-btn" @click="goHome">返回工作台</button>
    </div>

    <div v-else class="report-layout">
      <header class="topbar">
        <div class="top-left">
          <button class="ghost-btn" @click="goHome">← 返回</button>
          <div>
            <h1>选址决策报告</h1>
            <p>AI SITE INVESTMENT MEMO</p>
          </div>
        </div>

        <div class="top-actions">
          <button class="ghost-btn" @click="focusBestLocation">定位首选</button>
          <button class="ghost-btn" @click="copySummary">复制摘要</button>
          <button class="primary-btn" @click="exportReport">导出报告</button>
        </div>
      </header>

      <main class="report-main">
        <section class="content">
          <section class="hero-card">
            <div class="hero-copy">
              <span class="eyebrow">AI 决策摘要</span>
              <h2>{{ report.title }}</h2>
              <p>{{ report.summary || '该报告已完成候选点位、评分、风险与推荐结论的结构化整理。' }}</p>
            </div>

            <div class="hero-metrics">
              <div>
                <span>候选点</span>
                <strong>{{ report.locations.length }}</strong>
              </div>
              <div>
                <span>最高分</span>
                <strong>{{ bestLocation?.totalScore || '-' }}</strong>
              </div>
              <div>
                <span>首选点</span>
                <strong>{{ bestLocation?.name || '暂无' }}</strong>
              </div>
            </div>
          </section>

          <section class="section" v-if="report.comparisonTable.headers.length">
            <div class="section-head">
              <div>
                <h2>综合对比矩阵</h2>
                <p>把关键指标放在同一张表中，便于快速做投资判断。</p>
              </div>
            </div>
            <div class="table-card">
              <table>
                <thead>
                  <tr>
                    <th v-for="(h, i) in report.comparisonTable.headers" :key="i">{{ h }}</th>
                  </tr>
                </thead>
                <tbody>
                  <tr v-for="(row, ri) in report.comparisonTable.rows" :key="ri">
                    <td v-for="(cell, ci) in row" :key="ci">{{ cell }}</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </section>

          <section class="section">
            <div class="section-head">
              <div>
                <h2>候选点位评分</h2>
                <p>点击点位卡片，可在右侧地图中聚焦对应位置与覆盖半径。</p>
              </div>
            </div>

            <article
              v-for="loc in report.locations"
              :key="loc.id"
              class="location-card"
              :class="{ active: selectedLocation && selectedLocation.id === loc.id }"
              @click="selectLocation(loc)"
            >
              <div class="location-top">
                <div>
                  <div class="title-row">
                    <h3>{{ loc.name }}</h3>
                    <span :class="['tag', recommendClass(loc.recommendation)]">
                      {{ loc.recommendation }}
                    </span>
                  </div>
                  <p>{{ loc.address }}</p>
                </div>
                <div class="score">
                  <strong>{{ loc.totalScore }}</strong>
                  <span>总分</span>
                </div>
              </div>

              <div class="score-grid">
                <div v-for="item in loc.scoreItems" :key="item.name" class="score-item">
                  <div>
                    <span>{{ item.name }}</span>
                    <strong>{{ item.score }}</strong>
                  </div>
                  <div class="bar"><i :style="{ width: `${item.score}%` }"></i></div>
                </div>
              </div>

              <div class="tag-block">
                <strong>核心优势</strong>
                <span v-for="(item, i) in loc.advantages" :key="i" class="good">{{ item }}</span>
              </div>

              <div class="tag-block">
                <strong>主要风险</strong>
                <span v-for="(item, i) in loc.risks" :key="i" class="risk">{{ item }}</span>
              </div>
            </article>
          </section>

          <section class="section">
            <div class="section-head">
              <div>
                <h2>最终推荐</h2>
                <p>用于进入谈判、复核或放弃的优先级判断。</p>
              </div>
            </div>
            <div class="final-grid">
              <article v-if="report.finalRecommendation.firstChoice">
                <span>首选</span>
                <strong>{{ report.finalRecommendation.firstChoice }}</strong>
                <p>{{ report.finalRecommendation.firstReason }}</p>
              </article>
              <article v-if="report.finalRecommendation.secondChoice">
                <span>备选</span>
                <strong>{{ report.finalRecommendation.secondChoice }}</strong>
                <p>{{ report.finalRecommendation.secondReason }}</p>
              </article>
              <article v-if="report.finalRecommendation.cautiousChoice">
                <span>谨慎</span>
                <strong>{{ report.finalRecommendation.cautiousChoice }}</strong>
                <p>{{ report.finalRecommendation.cautiousReason }}</p>
              </article>
            </div>
          </section>

          <section class="section">
            <div class="section-head">
              <div>
                <h2>详细分析</h2>
                <p>保留智能体输出的完整推理、表格与执行建议。</p>
              </div>
            </div>
            <div class="analysis-card">
              <template v-if="analysisBlocks.length">
                <template v-for="(block, index) in analysisBlocks" :key="index">
                  <h2 v-if="block.type === 'heading1'">{{ block.content }}</h2>
                  <h3 v-else-if="block.type === 'heading2'">{{ block.content }}</h3>
                  <p v-else-if="block.type === 'paragraph'">{{ block.content }}</p>
                  <ul v-else-if="block.type === 'list'">
                    <li v-for="(li, i) in block.items" :key="i">{{ li }}</li>
                  </ul>
                  <div v-else-if="block.type === 'table'" class="table-card embedded">
                    <table>
                      <thead>
                        <tr>
                          <th v-for="(h, i) in block.headers" :key="i">{{ h }}</th>
                        </tr>
                      </thead>
                      <tbody>
                        <tr v-for="(row, ri) in block.rows" :key="ri">
                          <td v-for="(cell, ci) in row" :key="ci">{{ cell }}</td>
                        </tr>
                      </tbody>
                    </table>
                  </div>
                </template>
              </template>
              <p v-else>{{ report.detailedAnalysis || '暂无详细分析内容。' }}</p>
            </div>
          </section>
        </section>

        <aside class="map-aside">
          <div class="map-card">
            <div class="map-head">
              <div>
                <h2>点位覆盖地图</h2>
                <p>{{ mapRange }}km 商圈覆盖范围</p>
              </div>
              <select v-model="mapRange" @change="redrawMap">
                <option :value="1">1km</option>
                <option :value="2">2km</option>
                <option :value="3">3km</option>
              </select>
            </div>

            <div class="map-wrap">
              <div ref="reportMapEl" class="report-map"></div>
              <div v-if="mapLoading" class="map-state">
                <div class="loader small"></div>
                <span>地图加载中...</span>
              </div>
              <div v-if="mapError" class="map-state error">{{ mapError }}</div>
            </div>

            <div v-if="selectedLocation" class="selected-card">
              <span>当前聚焦</span>
              <strong>{{ selectedLocation.name }}</strong>
              <p>{{ selectedLocation.address }}</p>
              <div>
                <em>总分 {{ selectedLocation.totalScore }}</em>
                <em>{{ selectedLocation.recommendation }}</em>
              </div>
            </div>
          </div>
        </aside>
      </main>

      <div v-if="toastText" class="toast">{{ toastText }}</div>
    </div>
  </div>
</template>

<script setup>
import { computed, nextTick, onMounted, ref } from 'vue'
import { useRouter } from 'vue-router'
import { storage } from '../utils/storage'
import { normalizeReport, parseMarkdownLikeText } from '../utils/report'
import { loadAMap } from '../utils/amap'

const router = useRouter()
const loading = ref(true)
const report = ref(null)
const analysisBlocks = ref([])
const toastText = ref('')
const reportMapEl = ref(null)
const mapLoading = ref(false)
const mapError = ref('')
const mapRange = ref(2)
const selectedLocation = ref(null)

let AMapRef = null
let reportMap = null
let geocoder = null
let mapMarkers = []
let mapCircles = []

const bestLocation = computed(() => {
  if (!report.value || !report.value.locations.length) return null
  return [...report.value.locations].sort((a, b) => b.totalScore - a.totalScore)[0]
})

function showToast(text) {
  toastText.value = text
  setTimeout(() => {
    toastText.value = ''
  }, 1800)
}

function loadReport() {
  let reportData = storage.get('latestReportData', null)
  if (!reportData) {
    const latestReportId = storage.get('latestReportId', null)
    const reportHistory = storage.get('reportHistory', {})
    if (latestReportId && reportHistory[latestReportId]) reportData = reportHistory[latestReportId].data
  }
  if (!reportData) {
    loading.value = false
    return
  }

  const normalized = normalizeReport(reportData)
  normalized.locations = normalized.locations.map((loc, index) => {
    const raw = Array.isArray(reportData.locations) ? reportData.locations[index] || {} : {}
    return {
      ...loc,
      longitude: raw.longitude ?? raw.lng ?? raw.location?.longitude ?? raw.location?.lng ?? null,
      latitude: raw.latitude ?? raw.lat ?? raw.location?.latitude ?? raw.location?.lat ?? null
    }
  })

  report.value = normalized
  analysisBlocks.value = parseMarkdownLikeText(normalized.detailedAnalysis || '')
  selectedLocation.value = bestLocation.value || normalized.locations[0] || null
  loading.value = false
}

async function initReportMap() {
  if (!report.value) return
  try {
    mapLoading.value = true
    mapError.value = ''
    await nextTick()
    AMapRef = await loadAMap()
    if (!reportMapEl.value) return
    reportMap = new AMapRef.Map(reportMapEl.value, {
      zoom: 13,
      center: [118.76337, 32.06027],
      viewMode: '2D',
      mapStyle: 'amap://styles/darkblue'
    })
    geocoder = new AMapRef.Geocoder()
    await resolveLocationsCoordinates()
    drawAllLocations()
    if (selectedLocation.value) focusLocation(selectedLocation.value)
  } catch (err) {
    console.error('报告地图初始化失败:', err)
    mapError.value = '地图初始化失败，请检查高德 Key 或网络。'
  } finally {
    mapLoading.value = false
  }
}

async function resolveLocationsCoordinates() {
  for (const loc of report.value.locations || []) {
    if (loc.longitude && loc.latitude) continue
    const keyword = loc.address || loc.name
    if (!keyword) continue
    const point = await geocodeAddress(keyword)
    if (point) {
      loc.longitude = point.lng
      loc.latitude = point.lat
    }
  }
}

function geocodeAddress(address) {
  return new Promise(resolve => {
    geocoder.getLocation(address, (status, result) => {
      if (status === 'complete' && result.geocodes?.length) {
        const p = result.geocodes[0].location
        resolve({ lng: p.lng, lat: p.lat })
      } else {
        resolve(null)
      }
    })
  })
}

function clearMapLayers() {
  if (!reportMap) return
  if (mapMarkers.length) reportMap.remove(mapMarkers)
  if (mapCircles.length) reportMap.remove(mapCircles)
  mapMarkers = []
  mapCircles = []
}

function drawAllLocations() {
  if (!reportMap || !AMapRef || !report.value) return
  clearMapLayers()
  const overlays = []
  report.value.locations.forEach(loc => {
    if (!loc.longitude || !loc.latitude) return
    const position = [Number(loc.longitude), Number(loc.latitude)]
    const marker = new AMapRef.Marker({
      position,
      title: loc.name,
      label: {
        content: `<div class="amap-label"><strong>${shortLocationName(loc.name)}</strong><span>${loc.totalScore}分 · ${loc.recommendation}</span></div>`,
        direction: 'top'
      }
    })
    marker.on('click', () => selectLocation(loc))
    const circle = new AMapRef.Circle({
      center: position,
      radius: mapRange.value * 1000,
      strokeColor: getCircleColor(loc.recommendation),
      strokeOpacity: 0.9,
      strokeWeight: 2,
      fillColor: getCircleColor(loc.recommendation),
      fillOpacity: 0.13
    })
    mapMarkers.push(marker)
    mapCircles.push(circle)
    overlays.push(marker, circle)
  })
  if (mapMarkers.length) reportMap.add(mapMarkers)
  if (mapCircles.length) reportMap.add(mapCircles)
  if (overlays.length) reportMap.setFitView(overlays, false, [60, 60, 60, 60])
}

function focusLocation(loc) {
  if (!reportMap || !loc?.longitude || !loc?.latitude) return
  reportMap.setZoomAndCenter(15, [Number(loc.longitude), Number(loc.latitude)])
}

function selectLocation(loc) {
  selectedLocation.value = loc
  focusLocation(loc)
}

function focusBestLocation() {
  if (!bestLocation.value) return showToast('暂无首选点位')
  selectLocation(bestLocation.value)
  showToast('已定位到首选点位')
}

function redrawMap() {
  drawAllLocations()
  if (selectedLocation.value) focusLocation(selectedLocation.value)
}

function getCircleColor(rec) {
  if (rec === '首选') return '#67ffd0'
  if (rec === '次选' || rec === '备选') return '#ffd38a'
  return '#ff7c8a'
}

function shortLocationName(name = '') {
  const text = String(name || '未命名点位')
  return text.length > 12 ? `${text.slice(0, 12)}...` : text
}

function recommendClass(rec) {
  if (rec === '首选') return 'first'
  if (rec === '次选' || rec === '备选') return 'second'
  return 'cautious'
}

function goHome() {
  router.push('/')
}

function copySummary() {
  const text = `${report.value.title}\n\n${report.value.summary || ''}`
  navigator.clipboard.writeText(text)
  showToast('摘要已复制')
}

function buildFullReportText() {
  let text = `${report.value.title}\n\n${report.value.summary || ''}\n\n`
  text += '【候选点位分析】\n'
  report.value.locations.forEach((loc, index) => {
    text += `${index + 1}. ${loc.name}\n`
    text += `地址：${loc.address}\n总分：${loc.totalScore}\n推荐等级：${loc.recommendation}\n`
    text += `优势：${loc.advantages.join('；')}\n风险：${loc.risks.join('；')}\n\n`
  })
  if (report.value.detailedAnalysis) text += `【详细分析】\n${report.value.detailedAnalysis}`
  return text
}

function exportReport() {
  const blob = new Blob([buildFullReportText()], { type: 'text/plain;charset=utf-8' })
  const url = URL.createObjectURL(blob)
  const a = document.createElement('a')
  a.href = url
  a.download = `${report.value.title || '选址决策报告'}.txt`
  a.click()
  URL.revokeObjectURL(url)
  showToast('报告已导出')
}

onMounted(async () => {
  loadReport()
  if (report.value) await initReportMap()
})
</script>

<style scoped>
* {
  box-sizing: border-box;
}

.report-page {
  position: relative;
  min-height: 100vh;
  color: #edfaff;
  background:
    radial-gradient(circle at 16% 10%, rgba(20, 213, 255, 0.16), transparent 28%),
    radial-gradient(circle at 86% 20%, rgba(132, 97, 255, 0.14), transparent 30%),
    linear-gradient(135deg, #071019 0%, #0a1825 48%, #071016 100%);
}

.ambient-grid {
  position: fixed;
  inset: 0;
  pointer-events: none;
  opacity: 0.22;
  background-image:
    linear-gradient(rgba(255, 255, 255, 0.055) 1px, transparent 1px),
    linear-gradient(90deg, rgba(255, 255, 255, 0.055) 1px, transparent 1px);
  background-size: 48px 48px;
}

button,
select {
  font: inherit;
}

button {
  border: 0;
  cursor: pointer;
}

.state-page {
  position: relative;
  z-index: 1;
  min-height: 100vh;
  display: grid;
  place-items: center;
  align-content: center;
  gap: 16px;
}

.state-page h1,
.state-page p {
  margin: 0;
}

.empty-mark {
  width: 82px;
  height: 82px;
  display: grid;
  place-items: center;
  border-radius: 22px;
  color: #031018;
  font-weight: 1000;
  background: linear-gradient(135deg, #7cf4ff, #43e095);
}

.loader {
  width: 44px;
  height: 44px;
  border-radius: 50%;
  border: 4px solid rgba(255, 255, 255, 0.18);
  border-top-color: #67ffd0;
  animation: spin 0.8s linear infinite;
}

.loader.small {
  width: 26px;
  height: 26px;
  border-width: 3px;
}

.report-layout {
  position: relative;
  z-index: 1;
  height: 100vh;
  display: flex;
  flex-direction: column;
  min-height: 0;
}

.topbar {
  height: 82px;
  flex-shrink: 0;
  padding: 0 24px;
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 18px;
}

.top-left,
.top-actions,
.section-head,
.location-top,
.title-row,
.map-head {
  display: flex;
  align-items: center;
}

.top-left {
  gap: 14px;
}

.topbar h1,
.topbar p,
.section-head h2,
.section-head p,
.hero-card h2,
.hero-card p,
.map-head h2,
.map-head p {
  margin: 0;
}

.topbar h1 {
  font-size: 24px;
}

.topbar p,
.eyebrow,
.hero-metrics span {
  font-size: 12px;
  letter-spacing: 1.4px;
  color: rgba(237, 250, 255, 0.54);
}

.top-actions {
  gap: 9px;
  flex-wrap: wrap;
  justify-content: flex-end;
}

.ghost-btn,
.primary-btn {
  height: 38px;
  padding: 0 14px;
  border-radius: 11px;
  color: #dffcff;
  background: rgba(102, 236, 255, 0.08);
  border: 1px solid rgba(102, 236, 255, 0.16);
}

.primary-btn {
  color: #031018;
  font-weight: 900;
  background: linear-gradient(135deg, #7cf4ff, #43e095);
}

.report-main {
  flex: 1;
  min-height: 0;
  padding: 0 24px 24px;
  display: grid;
  grid-template-columns: minmax(0, 1fr) 430px;
  gap: 18px;
}

.content {
  min-height: 0;
  overflow-y: auto;
  padding-right: 4px;
}

.hero-card,
.table-card,
.location-card,
.final-grid article,
.analysis-card,
.map-card,
.selected-card {
  border: 1px solid rgba(102, 236, 255, 0.16);
  background: linear-gradient(180deg, rgba(10, 30, 44, 0.8), rgba(6, 18, 29, 0.92));
  box-shadow: 0 18px 50px rgba(0, 0, 0, 0.24);
  backdrop-filter: blur(18px);
}

.hero-card {
  display: grid;
  grid-template-columns: 1fr;
  gap: 18px;
  padding: 22px 24px;
  border-radius: 20px;
}

.hero-card h2 {
  margin-top: 10px;
  font-size: 30px;
  line-height: 1.25;
}

.hero-card p {
  margin-top: 12px;
  color: rgba(237, 250, 255, 0.72);
  line-height: 1.8;
}

.hero-metrics {
  display: grid;
  grid-template-columns: repeat(3, minmax(0, 1fr));
  gap: 10px;
}

.hero-metrics div {
  padding: 14px;
  border-radius: 15px;
  background: rgba(255, 255, 255, 0.045);
}

.hero-metrics strong {
  display: block;
  margin-top: 7px;
  font-size: 20px;
}

.section {
  margin-top: 22px;
}

.section-head {
  justify-content: space-between;
  margin-bottom: 13px;
}

.section-head h2 {
  font-size: 20px;
}

.section-head p {
  margin-top: 5px;
  color: rgba(237, 250, 255, 0.58);
  font-size: 13px;
}

.table-card {
  overflow-x: auto;
  padding: 16px;
  border-radius: 18px;
}

table {
  width: 100%;
  min-width: 720px;
  border-collapse: collapse;
}

th,
td {
  padding: 12px 10px;
  border: 1px solid rgba(255, 255, 255, 0.08);
  text-align: left;
  font-size: 13px;
}

th {
  color: #8fffee;
  background: rgba(102, 236, 255, 0.1);
}

.location-card {
  margin-bottom: 14px;
  padding: 18px;
  border-radius: 18px;
  cursor: pointer;
  transition: transform 0.2s ease, border-color 0.2s ease;
}

.location-card:hover,
.location-card.active {
  transform: translateY(-2px);
  border-color: rgba(103, 255, 208, 0.34);
}

.location-top {
  justify-content: space-between;
  gap: 16px;
}

.title-row {
  gap: 10px;
  flex-wrap: wrap;
}

.title-row h3 {
  margin: 0;
  font-size: 21px;
}

.location-card p {
  margin: 8px 0 0;
  color: rgba(237, 250, 255, 0.66);
  line-height: 1.6;
}

.tag {
  padding: 5px 10px;
  border-radius: 999px;
  font-size: 12px;
  font-weight: 900;
}

.tag.first {
  color: #031018;
  background: #67ffd0;
}

.tag.second {
  color: #3a2400;
  background: #ffd38a;
}

.tag.cautious {
  color: #fff;
  background: #ff7c8a;
}

.score {
  width: 78px;
  height: 78px;
  flex-shrink: 0;
  display: grid;
  place-items: center;
  border-radius: 50%;
  background:
    radial-gradient(circle at center, #071019 55%, transparent 56%),
    conic-gradient(#67ffd0 0 82%, rgba(255, 255, 255, 0.08) 0);
}

.score strong {
  color: #67ffd0;
  font-size: 26px;
}

.score span {
  margin-top: -26px;
  color: rgba(237, 250, 255, 0.56);
  font-size: 11px;
}

.score-grid {
  margin-top: 18px;
  display: grid;
  grid-template-columns: repeat(2, 1fr);
  gap: 12px;
}

.score-item div:first-child {
  display: flex;
  justify-content: space-between;
  font-size: 13px;
}

.score-item strong {
  color: #8fffee;
}

.bar {
  height: 8px;
  margin-top: 7px;
  overflow: hidden;
  border-radius: 999px;
  background: rgba(255, 255, 255, 0.08);
}

.bar i {
  display: block;
  height: 100%;
  border-radius: inherit;
  background: linear-gradient(90deg, #6cf6ff, #61ffa9);
}

.tag-block {
  margin-top: 16px;
  display: flex;
  gap: 8px;
  flex-wrap: wrap;
  align-items: center;
}

.tag-block strong {
  width: 100%;
  font-size: 13px;
}

.good,
.risk {
  padding: 6px 9px;
  border-radius: 999px;
  font-size: 12px;
}

.good {
  color: #9dffd6;
  background: rgba(103, 255, 208, 0.1);
}

.risk {
  color: #ffd0a4;
  background: rgba(255, 188, 122, 0.1);
}

.final-grid {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 12px;
}

.final-grid article {
  padding: 17px;
  border-radius: 17px;
}

.final-grid span {
  color: #8fffee;
  font-size: 12px;
}

.final-grid strong {
  display: block;
  margin-top: 8px;
  font-size: 18px;
}

.final-grid p {
  margin: 8px 0 0;
  color: rgba(237, 250, 255, 0.68);
  line-height: 1.7;
}

.analysis-card {
  padding: 20px;
  border-radius: 18px;
}

.analysis-card h2,
.analysis-card h3 {
  color: #8fffee;
}

.analysis-card p,
.analysis-card li {
  white-space: pre-wrap;
  color: rgba(237, 250, 255, 0.78);
  line-height: 1.9;
}

.embedded {
  margin: 12px 0;
}

.map-aside {
  min-height: 0;
}

.map-card {
  height: 100%;
  min-height: 0;
  display: flex;
  flex-direction: column;
  padding: 16px;
  border-radius: 20px;
}

.map-head {
  justify-content: space-between;
  gap: 12px;
  margin-bottom: 12px;
}

.map-head h2 {
  font-size: 18px;
}

.map-head p {
  margin-top: 5px;
  color: rgba(237, 250, 255, 0.56);
  font-size: 12px;
}

select {
  height: 38px;
  border-radius: 11px;
  color: #edfaff;
  background: rgba(255, 255, 255, 0.06);
  border: 1px solid rgba(102, 236, 255, 0.16);
}

.map-wrap {
  position: relative;
  flex: 1;
  min-height: 360px;
  overflow: hidden;
  border-radius: 16px;
  background: #06131f;
  border: 1px solid rgba(102, 236, 255, 0.16);
}

.report-map {
  width: 100%;
  height: 100%;
}

.map-state {
  position: absolute;
  inset: 0;
  z-index: 5;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 10px;
  background: rgba(3, 10, 18, 0.6);
}

.map-state.error {
  color: #ffdada;
  padding: 20px;
  text-align: center;
}

.selected-card {
  margin-top: 12px;
  padding: 14px;
  border-radius: 16px;
}

.selected-card span,
.selected-card em {
  color: rgba(237, 250, 255, 0.56);
  font-size: 12px;
  font-style: normal;
}

.selected-card strong {
  display: block;
  margin-top: 6px;
}

.selected-card p {
  margin: 7px 0;
  color: rgba(237, 250, 255, 0.66);
  line-height: 1.6;
}

.selected-card div {
  display: flex;
  gap: 8px;
}

.selected-card em {
  padding: 5px 9px;
  border-radius: 999px;
  color: #8fffee;
  background: rgba(102, 236, 255, 0.08);
}

.toast {
  position: fixed;
  z-index: 100;
  left: 50%;
  bottom: 28px;
  transform: translateX(-50%);
  padding: 11px 18px;
  border-radius: 999px;
  color: #fff;
  background: rgba(5, 17, 28, 0.95);
  border: 1px solid rgba(102, 236, 255, 0.2);
}

:deep(.amap-marker-label) {
  padding: 0;
  border: 0;
  background: transparent;
  box-shadow: none;
}

:deep(.amap-label) {
  max-width: 138px;
  padding: 6px 9px;
  color: #edfaff;
  background: rgba(3, 13, 22, 0.92);
  border: 1px solid rgba(103, 255, 208, 0.42);
  border-radius: 10px;
  box-shadow: 0 10px 28px rgba(0, 0, 0, 0.35);
  backdrop-filter: blur(10px);
}

:deep(.amap-label strong),
:deep(.amap-label span) {
  display: block;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

:deep(.amap-label strong) {
  color: #f6feff;
  font-size: 12px;
  line-height: 1.2;
}

:deep(.amap-label span) {
  margin-top: 3px;
  color: #67ffd0;
  font-size: 11px;
}

@keyframes spin {
  to {
    transform: rotate(360deg);
  }
}

@media (max-width: 1100px) {
  .report-layout {
    height: auto;
    min-height: 100vh;
  }

  .report-main {
    grid-template-columns: 1fr;
  }

  .content {
    overflow: visible;
  }

  .map-card {
    height: 560px;
  }
}

@media (max-width: 760px) {
  .topbar {
    height: auto;
    padding: 16px;
    align-items: flex-start;
    flex-direction: column;
  }

  .report-main {
    padding: 0 16px 18px;
  }

  .hero-card {
    grid-template-columns: 1fr;
  }

  .hero-metrics {
    grid-template-columns: 1fr;
  }

  .final-grid,
  .score-grid {
    grid-template-columns: 1fr;
  }

  .location-top {
    align-items: flex-start;
    flex-direction: column;
  }
}
</style>
