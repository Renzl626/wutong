import AMapLoader from '@amap/amap-jsapi-loader'

const AMAP_KEY = 'd3d6ccf3340e1b4f51824a87b6c0f72e'
const AMAP_SECURITY_JS_CODE = '9f0cbeb0738e1e19eb997357af0f9764' // 如果你开了安全密钥，就填；没有可先不写

let amapPromise = null

export function loadAMap() {
  if (amapPromise) return amapPromise

  if (AMAP_SECURITY_JS_CODE) {
    window._AMapSecurityConfig = {
      securityJsCode: AMAP_SECURITY_JS_CODE
    }
  }

  amapPromise = AMapLoader.load({
    key: AMAP_KEY,
    version: '2.0',
    plugins: [
      'AMap.Geolocation',
      'AMap.Geocoder',
      'AMap.AutoComplete',
      'AMap.PlaceSearch',
      'AMap.Marker',
      'AMap.Circle',
      'AMap.ToolBar',
      'AMap.Scale'
    ]
  })

  return amapPromise
}
