<template>
  <div class="amap-container">
    <div ref="mapRef" class="amap-box"></div>

    <div class="amap-info">
      <div class="amap-title">当前定位</div>
      <div class="amap-text">{{ locationText }}</div>
    </div>

    <button class="locate-btn" @click="locateMe">重新定位</button>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { loadAMap } from '../utils/amap'

const mapRef = ref(null)
let map = null
let marker = null
let circle = null
let geocoder = null

const locationText = ref('正在获取位置...')
const center = ref([118.76337, 32.06027]) // 默认南京
const radius = ref(2000) // 默认 2km

const emits = defineEmits(['location-change'])

onMounted(async () => {
  await initMap()
  await locateMe()
})

async function initMap() {
  const AMap = await loadAMap()

  map = new AMap.Map(mapRef.value, {
    zoom: 14,
    center: center.value,
    viewMode: '2D'
  })

  geocoder = new AMap.Geocoder()

  // 工具条 / 比例尺（可选）
  map.addControl(new AMap.ToolBar())
  map.addControl(new AMap.Scale())
}

async function locateMe() {
  if (!navigator.geolocation) {
    locationText.value = '浏览器不支持定位'
    return
  }

  navigator.geolocation.getCurrentPosition(
    async (pos) => {
      const lng = pos.coords.longitude
      const lat = pos.coords.latitude

      center.value = [lng, lat]
      await updateLocation(lng, lat)
    },
    () => {
      locationText.value = '定位失败，请允许浏览器定位权限'
    },
    {
      enableHighAccuracy: true,
      timeout: 10000,
      maximumAge: 0
    }
  )
}

async function updateLocation(lng, lat) {
  const AMap = await loadAMap()

  const lnglat = new AMap.LngLat(lng, lat)

  // 地图中心点
  map.setCenter([lng, lat])
  map.setZoom(16)

  // 先清除旧图层
  if (marker) {
    map.remove(marker)
    marker = null
  }

  if (circle) {
    map.remove(circle)
    circle = null
  }

  // 新 marker
  marker = new AMap.Marker({
    position: [lng, lat],
    title: '当前位置'
  })
  map.add(marker)

  // 新圆圈
  circle = new AMap.Circle({
    center: [lng, lat],
    radius: radius.value,
    strokeColor: '#00a0e9',
    strokeOpacity: 0.8,
    strokeWeight: 2,
    fillColor: '#00a0e9',
    fillOpacity: 0.12
  })
  map.add(circle)

  // 逆地理编码
  geocoder.getAddress(lnglat, (status, result) => {
    if (status === 'complete' && result.regeocode) {
      const addr = result.regeocode.formattedAddress
      locationText.value = addr
      emits('location-change', {
        longitude: lng,
        latitude: lat,
        address: addr
      })
    } else {
      locationText.value = `${lat.toFixed(5)}, ${lng.toFixed(5)}`
    }
  })
}
</script>

<style scoped>
.amap-container {
  position: relative;
  width: 100%;
  height: 320px;
  border-radius: 18px;
  overflow: hidden;
  background: #0b2233;
  border: 1px solid rgba(35, 215, 255, 0.18);
  box-shadow: 0 12px 30px rgba(0, 0, 0, 0.22);
}

.amap-box {
  width: 100%;
  height: 100%;
}

.amap-info {
  position: absolute;
  left: 14px;
  right: 14px;
  bottom: 14px;
  padding: 12px 14px;
  border-radius: 14px;
  background: rgba(5, 20, 32, 0.78);
  color: #fff;
  backdrop-filter: blur(8px);
}

.amap-title {
  font-size: 12px;
  color: #7feaff;
  margin-bottom: 4px;
  font-weight: 700;
}

.amap-text {
  font-size: 14px;
  line-height: 1.5;
  color: #eaf8ff;
}

.locate-btn {
  position: absolute;
  right: 14px;
  top: 14px;
  z-index: 5;
  padding: 8px 12px;
  border-radius: 999px;
  background: linear-gradient(180deg, #1ec6ff, #1679c8);
  color: #fff;
  border: none;
  font-size: 13px;
}
</style>