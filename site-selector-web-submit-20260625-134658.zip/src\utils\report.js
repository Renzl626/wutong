import { storage } from './storage'

export function generateReportId() {
  return 'report_' + Date.now() + '_' + Math.random().toString(16).slice(2)
}

export function formatReportTime() {
  const now = new Date()
  const y = now.getFullYear()
  const m = String(now.getMonth() + 1).padStart(2, '0')
  const d = String(now.getDate()).padStart(2, '0')
  const h = String(now.getHours()).padStart(2, '0')
  const min = String(now.getMinutes()).padStart(2, '0')
  return `${y}-${m}-${d} ${h}:${min}`
}

export function saveReportToStorage(reportJson) {
  if (!reportJson) return null

  const reportId = generateReportId()
  const reportHistory = storage.get('reportHistory', {})

  const reportItem = {
    id: reportId,
    title: reportJson.title || '选址分析报告',
    summary: reportJson.summary || '',
    createdAt: formatReportTime(),
    data: reportJson
  }

  reportHistory[reportId] = reportItem

  // 限制数量
  const MAX_REPORT_COUNT = 30
  const keys = Object.keys(reportHistory).sort((a, b) => {
    const ta = reportHistory[a].createdAt || ''
    const tb = reportHistory[b].createdAt || ''
    return tb.localeCompare(ta)
  })

  if (keys.length > MAX_REPORT_COUNT) {
    keys.slice(MAX_REPORT_COUNT).forEach(id => {
      delete reportHistory[id]
    })
  }

  storage.set('reportHistory', reportHistory)
  storage.set('latestReportId', reportId)
  storage.set('latestReportData', reportJson)

  return reportId
}

export function getReportById(reportId) {
  const reportHistory = storage.get('reportHistory', {})
  return reportHistory[reportId] || null
}

export function normalizeReport(report) {
  const safeReport = report || {}

  const locations = Array.isArray(safeReport.locations)
    ? safeReport.locations.map((location, index) => {
        const scoreBreakdown = location.scoreBreakdown || {}
        const scoreItems = Object.keys(scoreBreakdown).map(key => ({
          name: key,
          score: Number(scoreBreakdown[key]) || 0
        }))

        return {
          id: index,
          name: location.name || '未命名位置',
          address: location.address || '暂无详细地址',
          totalScore: Number(location.totalScore) || 0,
          scoreBreakdown,
          scoreItems,
          advantages: Array.isArray(location.advantages) ? location.advantages : [],
          risks: Array.isArray(location.risks) ? location.risks : [],
          recommendation: location.recommendation || '谨慎选择'
        }
      })
    : []

  return {
    title: safeReport.title || '选址分析报告',
    summary: safeReport.summary || '',
    locations,
    comparisonTable: safeReport.comparisonTable || { headers: [], rows: [] },
    finalRecommendation: safeReport.finalRecommendation || {},
    detailedAnalysis: safeReport.detailedAnalysis || ''
  }
}

export function parseMarkdownLikeText(text) {
  if (!text || typeof text !== 'string') return []

  const lines = text.replace(/\r\n/g, '\n').split('\n')
  const blocks = []
  let paragraph = []

  const flushParagraph = () => {
    const content = paragraph.join('\n').trim()
    if (content) {
      blocks.push({ type: 'paragraph', content })
    }
    paragraph = []
  }

  const isTableLine = line => {
    const t = line.trim()
    return t.startsWith('|') && t.endsWith('|') && t.length > 2
  }

  const isSeparatorLine = line => {
    const t = line.trim()
    return /^\|[\s\-:|]+\|$/.test(t) && t.includes('-')
  }

  let i = 0
  while (i < lines.length) {
    const line = lines[i].trim()

    if (!line) {
      flushParagraph()
      i++
      continue
    }

    if (isTableLine(line)) {
      flushParagraph()

      const tableLines = []
      while (i < lines.length && isTableLine(lines[i])) {
        tableLines.push(lines[i].trim())
        i++
      }

      if (tableLines.length >= 2 && tableLines.some(isSeparatorLine)) {
        const headers = tableLines[0]
          .split('|')
          .filter(cell => cell.trim() !== '')
          .map(cell => cell.trim())

        const sepIndex = tableLines.findIndex(isSeparatorLine)
        const rows = []

        for (let r = sepIndex + 1; r < tableLines.length; r++) {
          const row = tableLines[r]
            .split('|')
            .filter(cell => cell.trim() !== '')
            .map(cell => cell.trim())

          while (row.length < headers.length) row.push('')
          rows.push(row.slice(0, headers.length))
        }

        blocks.push({ type: 'table', headers, rows })
      } else {
        blocks.push({ type: 'paragraph', content: tableLines.join('\n') })
      }

      continue
    }

    if (line.startsWith('## ')) {
      flushParagraph()
      blocks.push({ type: 'heading2', content: line.replace(/^##\s+/, '') })
      i++
      continue
    }

    if (line.startsWith('# ')) {
      flushParagraph()
      blocks.push({ type: 'heading1', content: line.replace(/^#\s+/, '') })
      i++
      continue
    }

    if (line.startsWith('- ') || line.startsWith('* ') || /^(\d+)\.\s+/.test(line)) {
      flushParagraph()
      const items = []

      while (i < lines.length) {
        const l = lines[i].trim()
        if (l.startsWith('- ') || l.startsWith('* ') || /^(\d+)\.\s+/.test(l)) {
          items.push(l.replace(/^- /, '').replace(/^\* /, '').replace(/^(\d+)\.\s+/, ''))
          i++
        } else {
          break
        }
      }

      blocks.push({ type: 'list', items })
      continue
    }

    paragraph.push(lines[i])
    i++
  }

  flushParagraph()
  return blocks
}