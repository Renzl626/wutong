import { createRouter, createWebHashHistory } from 'vue-router'
import Home from '../pages/Home.vue'
import Report from '../pages/Report.vue'

const routes = [
  {
    path: '/',
    name: 'Home',
    component: Home
  },
  {
    path: '/report',
    name: 'Report',
    component: Report
  }
]

const router = createRouter({
  history: createWebHashHistory(),
  routes
})

export default router