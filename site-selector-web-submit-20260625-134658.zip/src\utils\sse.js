function parseSSEEvent(eventText) {
  const lines = eventText.split('\n')
  let eventName = ''
  const dataLines = []

  for (const line of lines) {
    if (line.startsWith('event:')) {
      eventName = line.slice(6).trim()
    } else if (line.startsWith('data:')) {
      dataLines.push(line.slice(5).trim())
    }
  }

  if (!dataLines.length) return null

  try {
    return {
      eventName,
      data: JSON.parse(dataLines.join('\n'))
    }
  } catch (e) {
    console.error('SSE JSON 解析失败:', e)
    return null
  }
}

export async function streamChat({ message, sessionId, onStatus, onFinal, onDone, onError }) {
  const response = await fetch('https://api.mzhyui.cn/chat', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Accept': 'text/event-stream'
    },
    body: JSON.stringify({
      message,
      sessionId
    })
  })

  if (!response.ok) {
    throw new Error(`请求失败：${response.status}`)
  }

  if (!response.body) {
    throw new Error('浏览器不支持流式响应')
  }

  const reader = response.body.getReader()
  const decoder = new TextDecoder('utf-8')

  let buffer = ''

  while (true) {
    const { done, value } = await reader.read()
    if (done) break

    buffer += decoder.decode(value, { stream: true })
    buffer = buffer.replace(/\r\n/g, '\n')

    const events = buffer.split('\n\n')
    buffer = events.pop() || ''

    for (const eventText of events) {
      const evt = parseSSEEvent(eventText)
      if (!evt) continue

      const { eventName, data } = evt
      const type = data.type || eventName || ''

      if (type === 'status') {
        onStatus && onStatus(data.message || '')
      } else if (type === 'final') {
        onFinal && onFinal(data.content || '')
      } else if (type === 'done') {
        onDone && onDone()
      } else if (type === 'error') {
        onError && onError(data.message || '智能体处理失败')
      }
    }
  }
}