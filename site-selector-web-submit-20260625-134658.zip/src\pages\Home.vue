<template>
  <div class="home-page">
    <div class="ambient-grid"></div>
    <div class="scanline"></div>

    <header class="topbar">
      <div class="brand">
        <div class="brand-mark">S</div>
        <div>
          <div class="brand-title">智汇铺手</div>
          <div class="brand-subtitle">AI RETAIL SITE INTELLIGENCE</div>
        </div>
      </div>

      <div class="top-metrics">
        <div class="metric-pill">
          <span>当前城市</span>
          <strong>{{ city }}</strong>
        </div>
        <div class="metric-pill">
          <span>研究半径</span>
          <strong>{{ range }}km</strong>
        </div>
        <div class="metric-pill online">
          <span>智能体</span>
          <strong>{{ isTyping ? '推演中' : '在线' }}</strong>
        </div>
      </div>

      <div class="top-actions">
        <button class="icon-btn" title="重新定位" @click="getLocation">⌖</button>
        <button class="icon-btn" title="清空会话" @click="clearCurrentChat">⌫</button>
        <button class="icon-btn" title="导出会话" @click="exportChat">⇩</button>
      </div>
    </header>

    <main class="workspace">
      <section class="map-panel">
        <div class="map-shell">
          <div class="map-search-bar">
            <input
              v-model="searchKeyword"
              class="map-search-input"
              placeholder="搜索商场、街道、小区、写字楼或具体地址"
              @keyup.enter="searchLocation"
            />
            <button class="map-search-btn" @click="searchLocation">
              {{ isSearchingLocation ? '搜索中' : '搜索' }}
            </button>
            <div v-if="searchResults.length" class="search-result-panel">
              <button
                v-for="item in searchResults"
                :key="item.id"
                class="search-result-item"
                @click="selectSearchResult(item)"
              >
                <strong>{{ item.name }}</strong>
                <span>{{ item.address }}</span>
                <em>{{ item.lng.toFixed(5) }}, {{ item.lat.toFixed(5) }}</em>
              </button>
            </div>
          </div>

          <div ref="mapEl" class="map-container"></div>

          <div class="map-chip left">
            <span class="live-dot"></span>
            商圈热力推演
          </div>
          <button class="locate-fab" title="定位当前位置" @click="getLocation">⌖</button>

          <div class="location-card">
            <div>
              <span class="eyebrow">当前选址点</span>
              <strong>{{ locationName || '正在获取定位...' }}</strong>
              <small>{{ longitude.toFixed(5) }}, {{ latitude.toFixed(5) }}</small>
            </div>
            <div class="location-actions">
              <button @click="addCurrentCandidate">加入对比池</button>
              <button class="secondary" @click="copyLocation">复制坐标</button>
            </div>
          </div>

          <div v-if="isLocating" class="locating-mask">
            <div class="loader"></div>
            <span>正在校准定位与商圈边界</span>
          </div>
        </div>

        <div class="insight-row">
          <article
            v-for="item in insightCards"
            :key="item.label"
            class="insight-card"
          >
            <span>{{ item.label }}</span>
            <strong>{{ item.value }}</strong>
            <em :class="item.tone">{{ item.delta }}</em>
          </article>
        </div>

        <section class="control-card">
          <div class="section-head">
            <div>
              <h2>AI 选址参数</h2>
              <p>设置业态、预算、面积与租金约束，智能体会按真实开店条件推演。</p>
            </div>
            <button class="ghost-btn" @click="fillChatDraft('请基于当前坐标生成一份结构化商铺选址报告')">
              写入对话框
            </button>
          </div>

          <div class="business-panel">
            <label class="field wide">
              <span>目标业态</span>
              <select v-model="businessType" @change="applyBusinessPreset">
                <option
                  v-for="item in businessTypes"
                  :key="item.name"
                  :value="item.name"
                >
                  {{ item.name }}
                </option>
              </select>
            </label>

            <label class="field">
              <span>投资预算</span>
              <div class="unit-input">
                <input v-model.number="investmentBudget" type="number" min="1" />
                <em>万元</em>
              </div>
            </label>

            <label class="field">
              <span>目标面积</span>
              <div class="unit-input">
                <input v-model.number="storeArea" type="number" min="1" />
                <em>㎡</em>
              </div>
            </label>

            <label class="field">
              <span>月租上限</span>
              <div class="unit-input">
                <input v-model.number="rentCeiling" type="number" min="1" />
                <em>万元</em>
              </div>
            </label>

            <label class="field">
              <span>客单价</span>
              <div class="unit-input">
                <input v-model.number="avgTicket" type="number" min="1" />
                <em>元</em>
              </div>
            </label>
          </div>

          <div class="business-summary">
            <div>
              <span>{{ selectedBusinessProfile.name }} 模型</span>
              <strong>{{ selectedBusinessProfile.focus }}</strong>
              <p>{{ selectedBusinessProfile.note }}</p>
            </div>
            <div class="summary-actions">
              <label class="context-toggle">
                <input v-model="includeBusinessParams" type="checkbox" />
                <span>纳入本次分析</span>
              </label>
              <button class="ghost-btn" @click="resetBusinessPreset">套用推荐值</button>
            </div>
          </div>

          <div class="range-segment">
            <button
              v-for="item in [1, 2, 3]"
              :key="item"
              :class="{ active: range === item }"
              @click="setRange(item)"
            >
              {{ item }}km
            </button>
          </div>
        </section>
      </section>

      <section class="decision-panel">
        <section class="context-card">
          <div class="context-card-head">
            <div>
              <h2>本次分析上下文</h2>
              <p>勾选后会随对话框内容一起发送给智能体。</p>
            </div>
          </div>
          <div class="context-mini-grid">
            <label class="context-mini">
              <input v-model="includeBusinessParams" type="checkbox" />
              <span>AI 参数</span>
              <strong>{{ businessType }} · {{ investmentBudget }}万</strong>
            </label>
            <label class="context-mini">
              <input v-model="includeCandidatePool" type="checkbox" />
              <span>候选池</span>
              <strong>{{ candidatePool.length }} 个点位</strong>
            </label>
          </div>
        </section>

        <section class="candidate-card">
          <div class="section-head compact">
            <div>
              <h2>候选点对比池</h2>
              <p>加入多个点位后，点击“写入对话框”再统一发送。</p>
            </div>
            <div class="candidate-actions">
              <button class="ghost-btn primary" @click="generateCandidateReport">
                写入对话框
              </button>
            </div>
          </div>

          <div v-if="candidatePool.length" class="candidate-list">
            <article
              v-for="item in candidatePool"
              :key="item.id"
              class="candidate-item"
              :class="{ active: activeCandidateId === item.id }"
            >
              <button class="candidate-main" @click="focusCandidate(item)">
                <div>
                  <span>{{ item.city }} · {{ item.range }}km</span>
                  <strong>{{ item.name }}</strong>
                  <small>{{ item.lng.toFixed(5) }}, {{ item.lat.toFixed(5) }}</small>
                </div>
                <b>{{ item.score }}</b>
              </button>
              <div class="candidate-metrics">
                <span>客流 {{ item.metrics.traffic }}</span>
                <span>租金 {{ item.metrics.rent }}</span>
                <span>竞品 {{ item.metrics.competition }}</span>
              </div>
              <button class="candidate-remove" @click="removeCandidate(item.id)">移除</button>
            </article>
          </div>

          <div v-else class="candidate-empty">
            <strong>还没有候选点</strong>
            <span>在地图上搜索或点击位置后，点“加入对比池”即可开始多点对比。</span>
          </div>
        </section>

        <section class="scenario-detail">
          <div>
            <span>策略草稿</span>
            <strong>{{ activeScenario.title }}</strong>
          </div>
          <div class="scenario-tabs">
            <button
              v-for="item in scenarioCards"
              :key="item.title"
              :class="{ active: activeScenario.title === item.title }"
              @click="selectScenario(item)"
            >
              {{ item.kicker }}
            </button>
          </div>
          <button class="ghost-btn primary" @click="fillChatDraft(activeScenario.question)">
            写入对话框
          </button>
        </section>

        <section class="history-card" :class="{ expanded: showReportHistory }">
          <div class="section-head compact">
            <div>
              <h2>历史报告</h2>
              <p>沉淀每次选址推演结果，方便复盘对比。</p>
            </div>
            <button class="ghost-btn" @click="toggleReportHistory">
              {{ showReportHistory ? '收起' : '查看' }}
            </button>
          </div>

          <div v-if="showReportHistory" class="history-list">
            <button
              v-for="item in reportHistoryList"
              :key="item.id"
              class="history-item"
              @click="openHistoryReport(item.id)"
            >
              <strong>{{ item.title }}</strong>
              <span>{{ item.createdAt }}</span>
              <em>{{ item.summary || '点击查看完整报告' }}</em>
            </button>
            <div v-if="reportHistoryList.length === 0" class="empty-hint">
              暂无历史报告
            </div>
          </div>
        </section>
      </section>

      <section class="agent-panel">
        <div class="agent-card">
          <div class="agent-header">
            <div class="agent-avatar">AI</div>
            <div>
              <h2>选址策略智能体</h2>
              <p>可追问租金、客群、竞品、转化、风险与开业打法。</p>
            </div>
            <button class="ghost-btn" @click="toggleChatHistory">历史</button>
          </div>

          <div v-if="showChatHistory" class="chat-history">
            <div class="history-title-row">
              <strong>会话历史</strong>
              <button @click="toggleChatHistory">×</button>
            </div>
            <button
              v-for="(item, index) in chatHistory"
              :key="item.id || index"
              class="history-item"
              @click="loadChatSession(index)"
            >
              <strong>{{ item.preview }}</strong>
              <span>{{ item.time }}</span>
            </button>
            <div v-if="chatHistory.length === 0" class="empty-hint">暂无会话历史</div>
          </div>

          <div ref="messagesEl" class="messages">
            <div
              v-for="(item, index) in currentChatMessages"
              :key="index"
              class="message-row"
              :class="item.role"
            >
              <div class="avatar">{{ item.role === 'user' ? '我' : 'AI' }}</div>

              <button
                v-if="item.isReportCard"
                class="bubble report-bubble"
                @click="viewReport(item.reportId)"
              >
                <span>选址分析报告已生成</span>
                <strong>{{ item.reportTitle }}</strong>
                <em>查看完整评分、风险与推荐结论 →</em>
              </button>

              <div v-else class="bubble">
                <template v-if="item.richContent && item.richContent.length">
                  <div v-for="(block, bi) in item.richContent" :key="bi">
                    <p v-if="block.type === 'text'" class="message-text">{{ block.value }}</p>
                    <div v-else-if="block.type === 'table'" class="table-wrap">
                      <table class="rich-table">
                        <thead>
                          <tr>
                            <th v-for="(h, hi) in block.value.headers" :key="hi">{{ h }}</th>
                          </tr>
                        </thead>
                        <tbody>
                          <tr v-for="(row, ri) in block.value.rows" :key="ri">
                            <td v-for="(cell, ci) in row" :key="ci">{{ cell }}</td>
                          </tr>
                        </tbody>
                      </table>
                    </div>
                  </div>
                </template>
                <p v-else class="message-text">{{ item.content }}</p>
              </div>
            </div>

            <div v-if="isTyping" class="message-row assistant">
              <div class="avatar">AI</div>
              <div class="bubble typing-bubble">
                <span></span>
                <span></span>
                <span></span>
              </div>
            </div>
          </div>

          <div class="input-zone">
            <div class="context-strip">
              <span>上下文</span>
              <strong>{{ locationName || '未选择位置' }}</strong>
              <em>{{ range }}km</em>
              <em v-if="includeBusinessParams">{{ businessType }}</em>
              <em v-if="includeCandidatePool">候选点 {{ candidatePool.length }}</em>
            </div>

            <div class="input-row">
              <input
                v-model="chatInput"
                class="chat-input"
                placeholder="例如：这个点适合做咖啡店吗？给我竞品和回本周期判断"
                @keyup.enter="sendChatMessage"
              />
              <button
                class="send-btn"
                :class="{ active: chatInput.trim() && !isTyping }"
                @click="sendChatMessage"
              >
                {{ isTyping ? '分析中' : '发送' }}
              </button>
            </div>

            <div class="quick-list">
              <button
                v-for="item in quickQuestions"
                :key="item.label"
                @click="fillChatDraft(item.question)"
              >
                {{ item.label }}
              </button>
            </div>
          </div>
        </div>
      </section>
    </main>

    <div v-if="toastText" class="toast">{{ toastText }}</div>
  </div>
</template>

<script setup>
import { computed, nextTick, onMounted, ref, watch } from 'vue'
import { useRouter } from 'vue-router'
import { streamChat } from '../utils/sse'
import { storage } from '../utils/storage'
import { saveReportToStorage } from '../utils/report'
import { loadAMap } from '../utils/amap'

const router = useRouter()

const searchKeyword = ref('')
const searchResults = ref([])
const isSearchingLocation = ref(false)
const mapEl = ref(null)
const messagesEl = ref(null)

let map = null
let marker = null
let circle = null
let geocoder = null
let autoComplete = null
let placeSearch = null

const city = ref('南京市')
const locationName = ref('')
const locationAddress = ref('')
const longitude = ref(118.76337)
const latitude = ref(32.06027)
const range = ref(2)
const businessType = ref(storage.get('businessType', '咖啡店'))
const investmentBudget = ref(storage.get('investmentBudget', 45))
const storeArea = ref(storage.get('storeArea', 80))
const rentCeiling = ref(storage.get('rentCeiling', 5))
const avgTicket = ref(storage.get('avgTicket', 32))

const chatInput = ref('')
const isTyping = ref(false)
const isLocating = ref(true)
const showChatHistory = ref(false)
const showReportHistory = ref(false)
const activeScenario = ref(null)
const candidatePool = ref(storage.get('candidatePool', []))
const activeCandidateId = ref(storage.get('activeCandidateId', null))
const includeBusinessParams = ref(storage.get('includeBusinessParams', true))
const includeCandidatePool = ref(storage.get('includeCandidatePool', true))
const chatHistory = ref([])
const currentChatMessages = ref([])
const toastText = ref('')
const pendingAssistantText = ref('')
const pendingFinalContent = ref('')
const sessionId = ref(
  storage.get('session_id', null) ||
    `web_${Date.now()}_${Math.random().toString(16).slice(2)}`
)

const quickQuestions = [
  { label: '业态匹配', question: '请基于我设置的目标业态、预算、面积和租金上限，判断当前点位是否匹配。' },
  { label: '竞品压力', question: '分析当前半径内的竞品压力、可差异化方向和避坑建议。' },
  { label: '回本周期', question: '请基于我的投资预算、面积、月租上限和客单价，估算当前点位回本周期。' },
  { label: '生成报告', question: '请基于当前坐标、城市、调研半径、目标业态和经营约束，生成一份结构化选址分析报告。' }
]

const businessTypes = [
  {
    name: '咖啡店',
    focus: '办公客流、停留场景、早午高峰',
    note: '更关注写字楼、学校、社区复合客群，以及租金与外卖覆盖的平衡。',
    budget: 45,
    area: 80,
    rent: 5,
    ticket: 32
  },
  {
    name: '茶饮店',
    focus: '年轻客群、即时消费、门头曝光',
    note: '更关注商场动线、学校与地铁口人流，竞品密度需要重点压测。',
    budget: 35,
    area: 45,
    rent: 4,
    ticket: 18
  },
  {
    name: '便利店',
    focus: '社区密度、夜间需求、复购频次',
    note: '更关注居住人口、通勤节点、夜间消费与周边生活配套。',
    budget: 60,
    area: 100,
    rent: 6,
    ticket: 25
  },
  {
    name: '轻餐饮',
    focus: '午晚餐峰值、后厨条件、外卖半径',
    note: '更关注明火/排烟条件、堂食翻台、外卖覆盖和租售比。',
    budget: 80,
    area: 120,
    rent: 7,
    ticket: 45
  },
  {
    name: '美业门店',
    focus: '女性客群、预约转化、社区信任',
    note: '更关注中高消费社区、停车便利、私域复购和楼上铺可见性。',
    budget: 50,
    area: 90,
    rent: 4,
    ticket: 168
  }
]

const selectedBusinessProfile = computed(() => {
  return businessTypes.find(item => item.name === businessType.value) || businessTypes[0]
})

const reportHistoryList = computed(() => {
  const history = storage.get('reportHistory', {})
  return Object.values(history)
    .sort((a, b) => String(b.createdAt || '').localeCompare(String(a.createdAt || '')))
    .slice(0, 8)
})

const insightCards = computed(() => [
  { label: '客流热度', value: `${84 + range.value}%`, delta: '+12% 环比', tone: 'up' },
  { label: '租金承压', value: range.value === 1 ? '中高' : '可控', delta: '需议价', tone: 'warn' },
  { label: '竞品密度', value: range.value === 3 ? '偏高' : '适中', delta: '可差异化', tone: 'neutral' },
  { label: '回本预测', value: `${10 + range.value}月`, delta: '模型估算', tone: 'up' }
])

const scenarioCards = [
  {
    kicker: '策略 A',
    title: '轻资产快闪验证',
    desc: '用 14 天测试成交、客单和复购，降低首次选址试错成本。',
    action: '适合不确定客流的点位',
    detail: '先用快闪摊、联名小店或临时外摆验证真实成交，再决定是否签长期合同。',
    question: '请为当前点位设计一个14天轻资产快闪验证方案，包括测试指标、预算和通过标准。'
  },
  {
    kicker: '策略 B',
    title: 'AI 竞品反定位',
    desc: '围绕差评关键词、价格带和营业时段，寻找竞争薄弱切口。',
    action: '适合竞品密集商圈',
    detail: '把竞品的价格带、差评、排队峰值和缺失品类拆开，找到可打穿的差异化入口。',
    question: '请基于当前点位做一份竞品反定位策略，指出可避开的红海方向和可切入的空白点。'
  },
  {
    kicker: '策略 C',
    title: '开业爆发模型',
    desc: '把周边写字楼、社区和地铁口拆成三类流量包做投放。',
    action: '适合确定要开业的点位',
    detail: '按办公、社区、通勤三类人群设计开业动作，把首周曝光、到店和复购拆成可执行任务。',
    question: '请为当前点位输出一份开业30天爆发模型，包括人群、活动、投放和复购动作。'
  }
]

activeScenario.value = scenarioCards[0]

function showToast(text) {
  toastText.value = text
  setTimeout(() => {
    toastText.value = ''
  }, 1800)
}

function initSession() {
  storage.set('session_id', sessionId.value)
  chatInput.value = storage.get('chatDraft', '')
  const savedMessages = storage.get('currentChatMessages', [])
  currentChatMessages.value = savedMessages.length
    ? savedMessages
    : [
    {
      role: 'assistant',
      content:
        '你好，我是你的选址策略智能体。你可以在地图上搜索或点击点位，我会结合位置、半径、客流、竞品与租金模型给出开店建议。'
    }
  ]
  loadChatHistory()
}

function loadChatHistory() {
  chatHistory.value = storage.get('chatHistory', [])
}

function saveChatHistory() {
  const msgs = currentChatMessages.value
  if (!msgs.length) return

  const now = new Date()
  const timeStr = `${now.getMonth() + 1}-${now.getDate()} ${now.getHours()}:${String(
    now.getMinutes()
  ).padStart(2, '0')}`
  const lastUserMessage = [...msgs].reverse().find(m => m.role === 'user')
  const preview = lastUserMessage ? `${lastUserMessage.content.slice(0, 28)}...` : '新的选址会话'
  const history = storage.get('chatHistory', [])

  history.unshift({
    id: Date.now(),
    time: timeStr,
    preview,
    messages: JSON.parse(JSON.stringify(msgs))
  })

  if (history.length > 20) history.pop()
  storage.set('chatHistory', history)
  chatHistory.value = history
}

function clearCurrentChat() {
  if (!confirm('确定清空当前会话吗？')) return
  currentChatMessages.value = [
    {
      role: 'assistant',
      content: '当前会话已清空。继续选择点位或告诉我你的目标业态，我会重新开始分析。'
    }
  ]
  storage.set('currentChatMessages', currentChatMessages.value)
  showToast('当前会话已清空')
}

function exportChat() {
  const text = currentChatMessages.value
    .map(m => {
      if (m.isReportCard) return `助手：已生成报告《${m.reportTitle}》`
      return `${m.role === 'user' ? '用户' : '助手'}：${m.content || ''}`
    })
    .join('\n\n')

  const blob = new Blob([text], { type: 'text/plain;charset=utf-8' })
  const url = URL.createObjectURL(blob)
  const a = document.createElement('a')
  a.href = url
  a.download = `选址智能体会话_${Date.now()}.txt`
  a.click()
  URL.revokeObjectURL(url)
  showToast('会话已导出')
}

function buildContextInfo() {
  storage.set('businessType', businessType.value)
  storage.set('investmentBudget', investmentBudget.value)
  storage.set('storeArea', storeArea.value)
  storage.set('rentCeiling', rentCeiling.value)
  storage.set('avgTicket', avgTicket.value)
  storage.set('candidatePool', candidatePool.value)
  storage.set('includeBusinessParams', includeBusinessParams.value)
  storage.set('includeCandidatePool', includeCandidatePool.value)

  const context = [
    '【当前选址上下文】',
    `位置：${locationName.value || '未选择'}`,
    `城市：${city.value}`,
    `调研半径：${range.value}km`,
    `经纬度：${longitude.value}, ${latitude.value}`
  ]

  if (includeBusinessParams.value) {
    context.push(
      '',
      '【经营约束】',
      `目标业态：${businessType.value}`,
      `业态关注点：${selectedBusinessProfile.value.focus}`,
      `投资预算：${investmentBudget.value || '未设置'}万元`,
      `目标面积：${storeArea.value || '未设置'}㎡`,
      `月租上限：${rentCeiling.value || '未设置'}万元`,
      `客单价假设：${avgTicket.value || '未设置'}元`
    )
  } else {
    context.push('', '【经营约束】本次未纳入 AI 选址参数。')
  }

  if (includeCandidatePool.value) {
    context.push('', '【候选点对比池】', buildCandidateContext())
  } else {
    context.push('', '【候选点对比池】本次未纳入候选点对比池。')
  }

  return context.join('\n')
}

function buildCandidateContext() {
  if (!candidatePool.value.length) return '暂无候选点。'
  return candidatePool.value
    .map((item, index) => {
      return [
        `${index + 1}. ${item.name}`,
        `城市：${item.city}`,
        `坐标：${item.lng}, ${item.lat}`,
        `半径：${item.range}km`,
        `综合评分：${item.score}`,
        `客流：${item.metrics.traffic}，租金健康：${item.metrics.rent}，竞品空隙：${item.metrics.competition}，业态匹配：${item.metrics.fit}`
      ].join('\n')
    })
    .join('\n\n')
}

function applyBusinessPreset() {
  storage.set('businessType', businessType.value)
  showToast(`已切换为${businessType.value}模型`)
}

function resetBusinessPreset() {
  const preset = selectedBusinessProfile.value
  investmentBudget.value = preset.budget
  storeArea.value = preset.area
  rentCeiling.value = preset.rent
  avgTicket.value = preset.ticket
  storage.set('investmentBudget', investmentBudget.value)
  storage.set('storeArea', storeArea.value)
  storage.set('rentCeiling', rentCeiling.value)
  storage.set('avgTicket', avgTicket.value)
  showToast('已套用业态推荐参数')
}

function scrollToBottom() {
  nextTick(() => {
    if (messagesEl.value) {
      messagesEl.value.scrollTop = messagesEl.value.scrollHeight
    }
  })
}

function parseMarkdownToRichContent(text) {
  if (!text || typeof text !== 'string') return null
  const lines = text.split('\n')
  const result = []
  let currentTextBlock = []
  const isTableLine = line => {
    const trimmed = line.trim()
    return trimmed.startsWith('|') && trimmed.endsWith('|') && trimmed.length > 2
  }
  const isSeparatorLine = line => {
    const trimmed = line.trim()
    return /^\|[\s\-:|]+\|$/.test(trimmed) && trimmed.includes('-')
  }
  const parseTable = startIdx => {
    const tableLines = []
    let idx = startIdx
    while (idx < lines.length && isTableLine(lines[idx])) {
      tableLines.push(lines[idx].trim())
      idx++
    }
    if (tableLines.length < 2 || !tableLines.some(isSeparatorLine)) {
      return { endIdx: startIdx, table: null }
    }
    const headers = tableLines[0]
      .split('|')
      .filter(cell => cell.trim() !== '')
      .map(cell => cell.trim())
    const sepIndex = tableLines.findIndex(isSeparatorLine)
    const rows = []
    for (let j = sepIndex + 1; j < tableLines.length; j++) {
      const cells = tableLines[j]
        .split('|')
        .filter(cell => cell.trim() !== '')
        .map(cell => cell.trim())
      while (cells.length < headers.length) cells.push('')
      rows.push(cells.slice(0, headers.length))
    }
    return { endIdx: startIdx + tableLines.length, table: { headers, rows } }
  }

  let i = 0
  while (i < lines.length) {
    if (isTableLine(lines[i])) {
      if (currentTextBlock.length) {
        result.push({ type: 'text', value: currentTextBlock.join('\n') })
        currentTextBlock = []
      }
      const { endIdx, table } = parseTable(i)
      if (table) {
        result.push({ type: 'table', value: table })
        i = endIdx
        continue
      }
    }
    currentTextBlock.push(lines[i])
    i++
  }

  if (currentTextBlock.length) result.push({ type: 'text', value: currentTextBlock.join('\n') })
  return result.length ? result : null
}

function updateMessageRichContent(index) {
  const msg = currentChatMessages.value[index]
  if (!msg || msg.role !== 'assistant') return
  const rich = parseMarkdownToRichContent(msg.content || '')
  if (rich && rich.some(x => x.type === 'table')) msg.richContent = rich
}

function appendAssistantContentBuffered(text) {
  pendingAssistantText.value += text
}

function flushAssistantText() {
  const text = pendingAssistantText.value
  pendingAssistantText.value = ''
  if (!text) return

  const msgs = currentChatMessages.value
  let idx = msgs.length - 1
  if (!msgs[idx] || msgs[idx].role !== 'assistant') {
    msgs.push({ role: 'assistant', content: '' })
    idx = msgs.length - 1
  }
  msgs[idx].content = (msgs[idx].content || '') + text
  updateMessageRichContent(idx)
  scrollToBottom()
}

function extractFirstJsonObject(text) {
  const start = text.indexOf('{')
  if (start === -1) return ''
  let depth = 0
  let inString = false
  let escape = false

  for (let i = start; i < text.length; i++) {
    const ch = text[i]
    if (escape) {
      escape = false
      continue
    }
    if (ch === '\\') {
      escape = true
      continue
    }
    if (ch === '"') {
      inString = !inString
      continue
    }
    if (inString) continue
    if (ch === '{') depth++
    if (ch === '}') {
      depth--
      if (depth === 0) return text.slice(start, i + 1)
    }
  }
  return ''
}

function tryParseReportJson(content) {
  const jsonStr = extractFirstJsonObject((content || '').trim())
  if (!jsonStr) return null
  try {
    const obj = JSON.parse(jsonStr)
    if (obj.title && (obj.locations || obj.sections)) return obj
    return null
  } catch (e) {
    console.warn('报告 JSON 解析失败:', e)
    return null
  }
}

function removeLastAssistantTextMessage() {
  const msgs = currentChatMessages.value
  const last = msgs[msgs.length - 1]
  if (last && last.role === 'assistant' && !last.isReportCard) msgs.pop()
}

function handleFinalContent(content) {
  pendingFinalContent.value += content || ''
  appendAssistantContentBuffered(content || '')
  flushAssistantText()
}

function finishAssistantResponse() {
  flushAssistantText()
  isTyping.value = false

  const reportJson = tryParseReportJson(pendingFinalContent.value)
  if (reportJson) {
    const reportId = saveReportToStorage(reportJson)
    removeLastAssistantTextMessage()
    currentChatMessages.value.push({
      role: 'assistant',
      isReportCard: true,
      reportId,
      reportTitle: reportJson.title || '选址分析报告',
      content: ''
    })
  }

  pendingFinalContent.value = ''
  saveChatHistory()
  scrollToBottom()
}

async function sendChatMessage() {
  const raw = chatInput.value.trim()
  if (!raw || isTyping.value) return

  storage.set('chatDraft', '')
  storage.set('includeBusinessParams', includeBusinessParams.value)
  storage.set('includeCandidatePool', includeCandidatePool.value)
  chatInput.value = ''
  currentChatMessages.value.push({ role: 'user', content: raw })
  isTyping.value = true
  pendingAssistantText.value = ''
  pendingFinalContent.value = ''
  scrollToBottom()

  const message = `${buildContextInfo()}\n\n【用户问题】\n${raw}`

  try {
    await streamChat({
      message,
      sessionId: sessionId.value,
      onStatus: text => {
        if (text) appendAssistantContentBuffered(`${text}\n`)
        flushAssistantText()
      },
      onFinal: handleFinalContent,
      onDone: finishAssistantResponse,
      onError: text => {
        appendAssistantContentBuffered(text || '智能体处理失败，请稍后重试。')
        finishAssistantResponse()
      }
    })
  } catch (err) {
    console.error(err)
    appendAssistantContentBuffered('请求失败，请检查网络或稍后重试。')
    finishAssistantResponse()
  }
}

function fillChatDraft(question) {
  chatInput.value = question
  storage.set('chatDraft', question)
  showToast('已写入对话框，请确认后发送')
}

function askQuickQuestion(question) {
  fillChatDraft(question)
}

function toggleChatHistory() {
  showChatHistory.value = !showChatHistory.value
}

function toggleReportHistory() {
  showReportHistory.value = !showReportHistory.value
}

function selectScenario(item) {
  activeScenario.value = item
}

function loadChatSession(index) {
  const session = chatHistory.value[index]
  if (!session) return
  currentChatMessages.value = JSON.parse(JSON.stringify(session.messages || []))
  showChatHistory.value = false
  scrollToBottom()
}

function openHistoryReport(id) {
  const history = storage.get('reportHistory', {})
  if (!history[id]) return
  storage.set('latestReportId', id)
  storage.set('latestReportData', history[id].data)
  router.push('/report')
}

function viewReport(id) {
  openHistoryReport(id)
}

function setRange(value) {
  range.value = value
  drawCircle()
  showToast(`调研半径已切换为 ${value}km`)
}

function scoreSeed(lng, lat, salt = 0) {
  const raw = Math.abs(Math.sin(Number(lng) * 12.9898 + Number(lat) * 78.233 + salt) * 10000)
  return Math.round(raw % 100)
}

function buildCandidateScore(lng, lat) {
  const businessBoost = businessType.value === '咖啡店' || businessType.value === '茶饮店' ? 8 : 4
  const traffic = Math.min(96, 72 + businessBoost + range.value * 2 + (scoreSeed(lng, lat, 1) % 10))
  const rent = Math.max(58, 88 - Math.round(Number(rentCeiling.value || 5) * 2) + (scoreSeed(lng, lat, 2) % 10))
  const competition = Math.max(55, 82 - range.value * 4 + (scoreSeed(lng, lat, 3) % 14))
  const fit = Math.min(96, 72 + (scoreSeed(lng, lat, businessType.value.length) % 18))
  const score = Math.round(traffic * 0.32 + rent * 0.22 + competition * 0.2 + fit * 0.26)
  return {
    score,
    metrics: { traffic, rent, competition, fit }
  }
}

function saveCandidatePool() {
  storage.set('candidatePool', candidatePool.value)
  storage.set('activeCandidateId', activeCandidateId.value)
}

function addCurrentCandidate() {
  const lng = Number(longitude.value)
  const lat = Number(latitude.value)
  const exists = candidatePool.value.some(item => {
    return Math.abs(item.lng - lng) < 0.00005 && Math.abs(item.lat - lat) < 0.00005
  })

  if (exists) {
    showToast('该点位已在对比池中')
    return
  }

  const scored = buildCandidateScore(lng, lat)
  const item = {
    id: `candidate_${Date.now()}_${Math.random().toString(16).slice(2)}`,
    name: locationName.value || locationAddress.value || '未命名候选点',
    address: locationAddress.value || locationName.value || '',
    city: city.value,
    lng,
    lat,
    range: range.value,
    businessType: businessType.value,
    score: scored.score,
    metrics: scored.metrics,
    createdAt: Date.now()
  }

  candidatePool.value.unshift(item)
  if (candidatePool.value.length > 8) candidatePool.value.pop()
  activeCandidateId.value = item.id
  saveCandidatePool()
  showToast('已加入候选点对比池')
}

function removeCandidate(id) {
  candidatePool.value = candidatePool.value.filter(item => item.id !== id)
  if (activeCandidateId.value === id) {
    activeCandidateId.value = candidatePool.value[0]?.id || null
  }
  saveCandidatePool()
  showToast('候选点已移除')
}

function focusCandidate(item) {
  activeCandidateId.value = item.id
  saveCandidatePool()
  updateLocationByLngLat(item.lng, item.lat)
  locationName.value = item.name
  locationAddress.value = item.address || item.name
  city.value = item.city || city.value
  range.value = item.range || range.value
  showToast('已聚焦候选点')
}

function generateCandidateReport() {
  if (candidatePool.value.length < 2) {
    showToast('至少加入 2 个候选点再生成对比报告')
    return
  }

  includeCandidatePool.value = true
  fillChatDraft(
    '请基于候选点对比池，为这些点位生成一份多点选址对比报告。需要包含综合排名、各点优劣势、租金与预算适配、目标业态匹配度、风险红线、首选/备选/谨慎选择，以及最终签约建议。'
  )
}

function copyLocation() {
  const text = `${locationName.value || locationAddress.value}\n${longitude.value},${latitude.value}`
  navigator.clipboard.writeText(text)
  showToast('位置已复制')
}

function renderMapCenter(lng, lat) {
  if (!map || !window.AMap) return
  map.setZoomAndCenter(15, [lng, lat])
  if (marker) map.remove(marker)
  marker = new window.AMap.Marker({ position: [lng, lat], title: '当前选址点' })
  map.add(marker)
  drawCircle()
}

function drawCircle() {
  if (!map || !window.AMap) return
  if (circle) map.remove(circle)
  circle = new window.AMap.Circle({
    center: [longitude.value, latitude.value],
    radius: range.value * 1000,
    strokeColor: '#18d5ff',
    strokeOpacity: 0.9,
    strokeWeight: 2,
    fillColor: '#18d5ff',
    fillOpacity: 0.14
  })
  map.add(circle)
}

function updateLocationByLngLat(lng, lat) {
  longitude.value = Number(lng)
  latitude.value = Number(lat)
  renderMapCenter(longitude.value, latitude.value)

  const AMap = window.AMap
  if (!AMap) return
  if (!geocoder) geocoder = new AMap.Geocoder()

  geocoder.getAddress([longitude.value, latitude.value], (status, result) => {
    if (status === 'complete' && result.regeocode) {
      const address = result.regeocode.formattedAddress
      const addressComponent = result.regeocode.addressComponent || {}
      locationAddress.value = address
      locationName.value = address
      city.value = addressComponent.city || addressComponent.province || city.value
    } else {
      locationName.value = `${latitude.value.toFixed(5)}, ${longitude.value.toFixed(5)}`
      locationAddress.value = locationName.value
    }
  })
}

function getLocation() {
  isLocating.value = true
  if (!navigator.geolocation) {
    isLocating.value = false
    showToast('浏览器不支持定位')
    return
  }

  navigator.geolocation.getCurrentPosition(
    pos => {
      updateLocationByLngLat(pos.coords.longitude, pos.coords.latitude)
      isLocating.value = false
    },
    () => {
      isLocating.value = false
      showToast('定位失败，请允许浏览器定位权限')
    },
    { enableHighAccuracy: true, timeout: 10000, maximumAge: 0 }
  )
}

async function initMap() {
  try {
    await nextTick()
    const AMap = await loadAMap()
    if (!mapEl.value) return

    map = new AMap.Map(mapEl.value, {
      zoom: 14,
      center: [longitude.value, latitude.value],
      viewMode: '2D',
      mapStyle: 'amap://styles/darkblue'
    })
    geocoder = new AMap.Geocoder()
    autoComplete = new AMap.AutoComplete({
      city: city.value,
      citylimit: true
    })
    placeSearch = new AMap.PlaceSearch({
      city: city.value,
      citylimit: true,
      type: '科教文化服务|地名地址信息|商务住宅|公司企业|购物服务|餐饮服务|生活服务|交通设施服务|风景名胜|政府机构及社会团体|医疗保健服务|住宿服务|金融保险服务',
      pageSize: 8,
      pageIndex: 1
    })
    map.addControl(new AMap.ToolBar())
    map.addControl(new AMap.Scale())
    renderMapCenter(longitude.value, latitude.value)
    map.on('click', e => {
      searchResults.value = []
      updateLocationByLngLat(e.lnglat.lng, e.lnglat.lat)
      showToast('已切换为地图选点位置')
    })
  } catch (err) {
    console.error('地图初始化失败:', err)
    showToast('地图初始化失败，请检查高德 Key')
  }
}

function normalizePoiResult(poi, index) {
  const loc = poi.location
  if (!loc) return null
  const lng = Number(loc.lng)
  const lat = Number(loc.lat)
  if (Number.isNaN(lng) || Number.isNaN(lat)) return null

  const area = [poi.pname, poi.cityname, poi.adname].filter(Boolean).join('')
  const address = poi.address && poi.address !== '[]'
    ? `${area}${poi.address}`
    : area || poi.name

  return {
    id: poi.id || `${lng}_${lat}_${index}`,
    name: poi.name || address,
    address,
    lng,
    lat
  }
}

function normalizeGeocodeResult(item, index, fallbackName) {
  const loc = item.location
  if (!loc) return null
  const lng = Number(loc.lng)
  const lat = Number(loc.lat)
  if (Number.isNaN(lng) || Number.isNaN(lat)) return null
  const address = item.formattedAddress || fallbackName
  return {
    id: `geo_${lng}_${lat}_${index}`,
    name: item.formattedAddress || fallbackName,
    address,
    lng,
    lat
  }
}

function normalizeAutoCompleteTip(tip, index) {
  const loc = tip.location
  if (!loc) return null
  const lng = Number(loc.lng)
  const lat = Number(loc.lat)
  if (Number.isNaN(lng) || Number.isNaN(lat)) return null
  const area = [tip.district, tip.address].filter(Boolean).join('')
  return {
    id: tip.id || `tip_${lng}_${lat}_${index}`,
    name: tip.name || area,
    address: area || tip.name,
    lng,
    lat
  }
}

function normalizeSearchText(text) {
  return String(text || '')
    .replace(/\s+/g, '')
    .replace(/[()（）\-_/·.。,:：，]/g, '')
    .toLowerCase()
}

function getCoreSearchKeyword(keyword) {
  const normalizedCity = normalizeSearchText(city.value)
  const cityWithoutSuffix = normalizedCity.replace(/市$/, '')
  let core = normalizeSearchText(keyword)

  core = core.replace(/^江苏省/, '').replace(/^江苏/, '')

  if (normalizedCity && core.startsWith(normalizedCity)) {
    core = core.slice(normalizedCity.length)
  } else if (cityWithoutSuffix && core.startsWith(cityWithoutSuffix)) {
    core = core.slice(cityWithoutSuffix.length)
  }

  return core || normalizeSearchText(keyword)
}

function isRelevantSearchResult(item, keyword) {
  const raw = normalizeSearchText(keyword)
  const core = getCoreSearchKeyword(keyword)
  const haystack = normalizeSearchText(`${item.name}${item.address}`)
  const requiredTerms = [core, raw]
    .filter(Boolean)
    .filter(term => term.length >= 3)

  if (!requiredTerms.length) return true
  return requiredTerms.some(term => haystack.includes(term))
}

function rankSearchResults(results, keyword) {
  const core = getCoreSearchKeyword(keyword)
  const raw = normalizeSearchText(keyword)

  return [...results].sort((a, b) => {
    const aName = normalizeSearchText(a.name)
    const bName = normalizeSearchText(b.name)
    const aText = normalizeSearchText(`${a.name}${a.address}`)
    const bText = normalizeSearchText(`${b.name}${b.address}`)
    const score = (name, text) => {
      let value = 0
      if (core && name === core) value += 100
      if (core && name.includes(core)) value += 60
      if (raw && text.includes(raw)) value += 40
      if (core && text.includes(core)) value += 30
      return value
    }
    return score(bName, bText) - score(aName, aText)
  })
}

function selectSearchResult(item) {
  updateLocationByLngLat(item.lng, item.lat)
  locationName.value = item.name
  locationAddress.value = item.address
  searchKeyword.value = item.name
  searchResults.value = []
  showToast('已切换为选中的搜索结果')
}

function searchLocation() {
  const keyword = searchKeyword.value.trim()
  if (!keyword) {
    showToast('请输入要搜索的位置')
    return
  }
  if (!window.AMap) return
  if (!geocoder) geocoder = new window.AMap.Geocoder()
  if (!autoComplete && window.AMap.AutoComplete) {
    autoComplete = new window.AMap.AutoComplete({
      city: city.value,
      citylimit: true
    })
  }
  if (!placeSearch && window.AMap.PlaceSearch) {
    placeSearch = new window.AMap.PlaceSearch({
      city: city.value,
      citylimit: true,
      type: '科教文化服务|地名地址信息|商务住宅|公司企业|购物服务|餐饮服务|生活服务|交通设施服务|风景名胜|政府机构及社会团体|医疗保健服务|住宿服务|金融保险服务',
      pageSize: 8,
      pageIndex: 1
    })
  }

  const coreKeyword = getCoreSearchKeyword(keyword)
  const placeKeyword = coreKeyword.length >= 3 ? coreKeyword : keyword
  const fullKeyword = keyword.includes(city.value) ? keyword : `${city.value}${keyword}`
  isSearchingLocation.value = true
  searchResults.value = []

  const fallbackGeocode = () => {
    geocoder.getLocation(fullKeyword, (status, result) => {
      isSearchingLocation.value = false
      if (status === 'complete' && result.geocodes && result.geocodes.length > 0) {
        const matches = result.geocodes
          .map((item, index) => normalizeGeocodeResult(item, index, fullKeyword))
          .filter(Boolean)
          .slice(0, 8)
        searchResults.value = rankSearchResults(matches, keyword)
        showToast(searchResults.value.length ? '请选择一个匹配地点' : '未找到高度匹配地点，请换个关键词')
      } else {
        showToast('未找到该位置，请换个关键词')
      }
    })
  }

  const searchByPlace = () => {
    if (!placeSearch) {
      fallbackGeocode()
      return
    }

    placeSearch.search(placeKeyword, (status, result) => {
      if (status === 'complete' && result.poiList && result.poiList.pois?.length) {
        const matches = result.poiList.pois
          .map((item, index) => normalizePoiResult(item, index))
          .filter(Boolean)

        if (matches.length) {
          isSearchingLocation.value = false
          searchResults.value = rankSearchResults(matches, keyword)
          showToast('请选择一个匹配地点')
          return
        }
      }

      fallbackGeocode()
    })
  }

  if (!autoComplete) {
    searchByPlace()
    return
  }

  autoComplete.search(keyword, (status, result) => {
    if (status === 'complete' && Array.isArray(result.tips) && result.tips.length) {
      const matches = result.tips
        .map((item, index) => normalizeAutoCompleteTip(item, index))
        .filter(Boolean)

      if (matches.length) {
        isSearchingLocation.value = false
        searchResults.value = rankSearchResults(matches, keyword)
        showToast('请选择一个匹配地点')
        return
      }
    }

    searchByPlace()
  })
}

watch(
  currentChatMessages,
  value => {
    storage.set('currentChatMessages', JSON.parse(JSON.stringify(value || [])))
  },
  { deep: true }
)

onMounted(async () => {
  initSession()
  await initMap()
  getLocation()
})
</script>

<style scoped>
* {
  box-sizing: border-box;
}

.home-page {
  position: relative;
  min-height: 100vh;
  overflow: hidden;
  color: #edfaff;
  background:
    radial-gradient(circle at 18% 12%, rgba(20, 213, 255, 0.18), transparent 26%),
    radial-gradient(circle at 85% 18%, rgba(132, 97, 255, 0.16), transparent 28%),
    radial-gradient(circle at 72% 92%, rgba(48, 255, 190, 0.12), transparent 28%),
    linear-gradient(135deg, #071019 0%, #0a1825 46%, #071016 100%);
}

.ambient-grid,
.scanline {
  position: fixed;
  inset: 0;
  pointer-events: none;
}

.ambient-grid {
  opacity: 0.24;
  background-image:
    linear-gradient(rgba(255, 255, 255, 0.055) 1px, transparent 1px),
    linear-gradient(90deg, rgba(255, 255, 255, 0.055) 1px, transparent 1px);
  background-size: 48px 48px;
}

.scanline {
  opacity: 0.18;
  background: linear-gradient(180deg, transparent, rgba(25, 214, 255, 0.12), transparent);
  animation: scan 7s linear infinite;
}

.topbar {
  position: relative;
  z-index: 2;
  height: 82px;
  padding: 0 24px;
  display: grid;
  grid-template-columns: auto 1fr auto;
  align-items: center;
  gap: 22px;
}

.brand,
.top-metrics,
.top-actions,
.agent-header,
.section-head,
.input-row,
.context-strip,
.radar-meta,
.location-card,
.history-title-row {
  display: flex;
  align-items: center;
}

.brand {
  gap: 14px;
}

.brand-mark {
  width: 48px;
  height: 48px;
  display: grid;
  place-items: center;
  border-radius: 14px;
  color: #031018;
  font-weight: 1000;
  background: linear-gradient(135deg, #80f6ff, #39d98a);
  box-shadow: 0 0 32px rgba(44, 227, 255, 0.35);
}

.brand-title {
  font-size: 24px;
  font-weight: 900;
}

.brand-subtitle {
  margin-top: 2px;
  font-size: 11px;
  letter-spacing: 2px;
  color: rgba(237, 250, 255, 0.54);
}

.top-metrics {
  justify-content: center;
  gap: 10px;
}

.metric-pill,
.icon-btn,
.ghost-btn,
.control-card,
.history-card,
.context-card,
.candidate-card,
.agent-card,
.insight-card {
  border: 1px solid rgba(102, 236, 255, 0.16);
  background: linear-gradient(180deg, rgba(10, 30, 44, 0.78), rgba(6, 18, 29, 0.9));
  box-shadow: 0 18px 50px rgba(0, 0, 0, 0.24);
  backdrop-filter: blur(18px);
}

.metric-pill {
  min-width: 118px;
  padding: 9px 12px;
  border-radius: 12px;
}

.metric-pill span,
.insight-card span,
.eyebrow {
  display: block;
  font-size: 12px;
  color: rgba(237, 250, 255, 0.54);
}

.metric-pill strong {
  display: block;
  margin-top: 3px;
  font-size: 14px;
}

.metric-pill.online strong,
.up {
  color: #68ffc4;
}

.top-actions {
  justify-content: flex-end;
  gap: 8px;
}

button,
input {
  font: inherit;
}

button {
  border: 0;
  cursor: pointer;
}

.icon-btn {
  width: 42px;
  height: 42px;
  border-radius: 12px;
  color: #ddfbff;
}

.workspace {
  position: relative;
  z-index: 1;
  height: calc(100vh - 82px);
  padding: 0 24px 24px;
  display: grid;
  grid-template-columns: minmax(390px, 37%) minmax(430px, 31%) minmax(390px, 32%);
  gap: 18px;
  min-height: 0;
}

.map-panel,
.decision-panel,
.agent-panel {
  min-height: 0;
  display: flex;
  flex-direction: column;
  gap: 12px;
}

.decision-panel {
  overflow: hidden;
  padding-right: 2px;
}

.map-shell {
  position: relative;
  flex: 1;
  min-height: 360px;
  overflow: hidden;
  border-radius: 20px;
  background: #06131f;
  border: 1px solid rgba(102, 236, 255, 0.2);
  box-shadow: 0 24px 70px rgba(0, 0, 0, 0.36);
}

.map-container {
  width: 100%;
  height: 100%;
}

.map-search-bar {
  position: absolute;
  z-index: 5;
  left: 16px;
  right: 72px;
  top: 16px;
  display: flex;
  gap: 8px;
}

.search-result-panel {
  position: absolute;
  left: 0;
  right: 0;
  top: 52px;
  max-height: 300px;
  padding: 8px;
  overflow-y: auto;
  border-radius: 14px;
  background: rgba(5, 17, 28, 0.96);
  border: 1px solid rgba(102, 236, 255, 0.22);
  box-shadow: 0 22px 70px rgba(0, 0, 0, 0.42);
  backdrop-filter: blur(12px);
}

.search-result-item {
  width: 100%;
  padding: 11px 12px;
  display: grid;
  gap: 4px;
  text-align: left;
  border-radius: 10px;
  color: #edfaff;
  background: transparent;
  border: 1px solid transparent;
}

.search-result-item:hover {
  background: rgba(102, 236, 255, 0.08);
  border-color: rgba(102, 236, 255, 0.16);
}

.search-result-item strong {
  font-size: 14px;
}

.search-result-item span {
  color: rgba(237, 250, 255, 0.64);
  font-size: 12px;
  line-height: 1.35;
}

.search-result-item em {
  color: #67ffd0;
  font-size: 11px;
  font-style: normal;
}

.map-search-input,
.chat-input {
  outline: none;
  color: #fff;
  background: rgba(4, 16, 26, 0.82);
  border: 1px solid rgba(102, 236, 255, 0.18);
}

.map-search-input {
  flex: 1;
  height: 44px;
  min-width: 0;
  padding: 0 14px;
  border-radius: 12px;
}

.map-search-btn,
.send-btn.active,
.ghost-btn.primary {
  color: #031018;
  background: linear-gradient(135deg, #7cf4ff, #43e095);
}

.map-search-btn {
  width: 76px;
  border-radius: 12px;
  font-weight: 900;
}

.map-chip {
  position: absolute;
  z-index: 4;
  top: 72px;
  left: 16px;
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 8px 12px;
  border-radius: 999px;
  background: rgba(4, 16, 26, 0.78);
  border: 1px solid rgba(102, 236, 255, 0.18);
}

.live-dot {
  width: 8px;
  height: 8px;
  border-radius: 50%;
  background: #55ffd1;
  box-shadow: 0 0 16px rgba(85, 255, 209, 0.9);
}

.locate-fab {
  position: absolute;
  z-index: 6;
  right: 16px;
  top: 16px;
  width: 44px;
  height: 44px;
  border-radius: 12px;
  color: #031018;
  font-size: 20px;
  font-weight: 900;
  background: linear-gradient(135deg, #7cf4ff, #43e095);
}

.location-card {
  position: absolute;
  z-index: 5;
  left: 16px;
  right: 16px;
  bottom: 16px;
  justify-content: space-between;
  gap: 14px;
  padding: 14px;
  border-radius: 16px;
  background: rgba(4, 16, 26, 0.84);
  border: 1px solid rgba(102, 236, 255, 0.18);
  backdrop-filter: blur(18px);
}

.location-actions {
  flex-shrink: 0;
  display: flex;
  gap: 8px;
}

.location-card strong {
  display: -webkit-box;
  margin-top: 5px;
  line-height: 1.4;
  overflow: hidden;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
}

.location-card small {
  display: block;
  margin-top: 6px;
  color: rgba(237, 250, 255, 0.58);
}

.location-card button,
.ghost-btn {
  flex-shrink: 0;
  height: 38px;
  padding: 0 13px;
  border-radius: 11px;
  color: #dffcff;
}

.location-card button {
  color: #031018;
  font-weight: 900;
  background: linear-gradient(135deg, #f3feff, #67ffd0);
  box-shadow: 0 10px 24px rgba(103, 255, 208, 0.22);
}

.location-card button.secondary {
  color: #dffcff;
  background: rgba(4, 16, 26, 0.78);
  border: 1px solid rgba(102, 236, 255, 0.18);
  box-shadow: none;
}

.ghost-btn {
  background: rgba(102, 236, 255, 0.08);
}

.locating-mask {
  position: absolute;
  inset: 0;
  z-index: 8;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 12px;
  background: rgba(3, 10, 18, 0.55);
}

.loader {
  width: 28px;
  height: 28px;
  border-radius: 50%;
  border: 3px solid rgba(255, 255, 255, 0.18);
  border-top-color: #6fffe0;
  animation: spin 0.8s linear infinite;
}

.insight-row {
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  gap: 10px;
}

.insight-card {
  min-width: 0;
  padding: 13px;
  border-radius: 14px;
}

.insight-card strong {
  display: block;
  margin-top: 7px;
  font-size: 18px;
}

.insight-card em {
  display: block;
  margin-top: 5px;
  font-style: normal;
  font-size: 12px;
}

.warn {
  color: #ffd38a;
}

.neutral {
  color: #8fe9ff;
}

.control-card,
.history-card,
.context-card,
.candidate-card,
.agent-card {
  border-radius: 16px;
  padding: 12px;
}

.section-head {
  justify-content: space-between;
  gap: 12px;
}

.section-head h2,
.agent-header h2,
.score-copy h1 {
  margin: 0;
}

.section-head h2,
.agent-header h2 {
  font-size: 16px;
}

.section-head p,
.agent-header p {
  margin: 5px 0 0;
  color: rgba(237, 250, 255, 0.6);
  line-height: 1.6;
  font-size: 11px;
}

.range-segment {
  margin-top: 14px;
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 10px;
}

.business-panel {
  margin-top: 15px;
  display: grid;
  grid-template-columns: repeat(4, minmax(0, 1fr));
  gap: 10px;
}

.field {
  min-width: 0;
  display: grid;
  gap: 7px;
}

.field.wide {
  grid-column: span 2;
}

.field span {
  color: rgba(237, 250, 255, 0.58);
  font-size: 12px;
}

.field select,
.unit-input {
  width: 100%;
  height: 42px;
  border-radius: 12px;
  color: #edfaff;
  background: rgba(4, 16, 26, 0.78);
  border: 1px solid rgba(102, 236, 255, 0.16);
}

.field select {
  padding: 0 12px;
  outline: none;
}

.unit-input {
  display: flex;
  align-items: center;
  overflow: hidden;
}

.unit-input input {
  min-width: 0;
  flex: 1;
  height: 100%;
  padding: 0 10px;
  color: #fff;
  outline: none;
  border: 0;
  background: transparent;
}

.unit-input em {
  flex-shrink: 0;
  padding: 0 10px;
  color: #67ffd0;
  font-size: 12px;
  font-style: normal;
}

.business-summary {
  margin-top: 12px;
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 12px;
  padding: 12px;
  border-radius: 14px;
  background: rgba(103, 255, 208, 0.06);
  border: 1px solid rgba(103, 255, 208, 0.14);
}

.summary-actions,
.candidate-actions {
  flex-shrink: 0;
  display: flex;
  align-items: center;
  gap: 9px;
}

.candidate-actions {
  justify-content: flex-end;
  flex-wrap: wrap;
}

.context-toggle {
  height: 34px;
  display: inline-flex;
  align-items: center;
  gap: 7px;
  padding: 0 10px;
  border-radius: 999px;
  color: rgba(237, 250, 255, 0.78);
  background: rgba(255, 255, 255, 0.055);
  border: 1px solid rgba(102, 236, 255, 0.14);
  font-size: 12px;
  white-space: nowrap;
}

.context-toggle input {
  width: 15px;
  height: 15px;
  accent-color: #67ffd0;
}

.context-toggle span {
  color: inherit;
  font-size: 12px;
}

.business-summary span {
  color: rgba(237, 250, 255, 0.54);
  font-size: 12px;
}

.business-summary strong {
  display: block;
  margin-top: 4px;
  color: #f6feff;
}

.business-summary p {
  margin: 5px 0 0;
  color: rgba(237, 250, 255, 0.62);
  line-height: 1.5;
  font-size: 12px;
}

.range-segment button {
  height: 42px;
  border-radius: 12px;
  color: rgba(237, 250, 255, 0.72);
  background: rgba(255, 255, 255, 0.05);
  border: 1px solid rgba(255, 255, 255, 0.08);
}

.range-segment button.active {
  color: #031018;
  font-weight: 900;
  background: linear-gradient(135deg, #7cf4ff, #43e095);
}

.context-card-head h2,
.context-card-head p {
  margin: 0;
}

.context-card-head h2 {
  font-size: 16px;
}

.context-card-head p {
  margin-top: 4px;
  color: rgba(237, 250, 255, 0.56);
  font-size: 12px;
}

.context-mini-grid {
  margin-top: 9px;
  display: grid;
  grid-template-columns: repeat(2, minmax(0, 1fr));
  gap: 8px;
}

.context-mini {
  min-width: 0;
  min-height: 50px;
  padding: 8px 10px;
  display: grid;
  grid-template-columns: auto 1fr;
  column-gap: 8px;
  row-gap: 3px;
  align-items: center;
  border-radius: 12px;
  background: rgba(255, 255, 255, 0.045);
  border: 1px solid rgba(255, 255, 255, 0.07);
}

.context-mini input {
  grid-row: span 2;
  width: 16px;
  height: 16px;
  accent-color: #67ffd0;
}

.context-mini span {
  color: rgba(237, 250, 255, 0.58);
  font-size: 11px;
}

.context-mini strong {
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  font-size: 13px;
}

.candidate-card {
  flex: 0 1 auto;
  min-height: 0;
  display: flex;
  flex-direction: column;
}

.candidate-list {
  margin-top: 10px;
  display: flex;
  flex-direction: column;
  gap: 8px;
  min-height: 0;
  max-height: clamp(260px, 46vh, 430px);
  overflow-y: auto;
  padding-right: 3px;
}

.candidate-item {
  position: relative;
  flex: 0 0 auto;
  padding: 9px;
  border-radius: 13px;
  background: rgba(255, 255, 255, 0.045);
  border: 1px solid rgba(255, 255, 255, 0.07);
}

.candidate-item.active {
  border-color: rgba(103, 255, 208, 0.34);
  background: rgba(103, 255, 208, 0.07);
}

.candidate-main {
  width: 100%;
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 12px;
  padding: 0 50px 0 0;
  color: #edfaff;
  text-align: left;
  background: transparent;
}

.candidate-main span,
.candidate-main small {
  display: block;
  color: rgba(237, 250, 255, 0.52);
  font-size: 11px;
}

.candidate-main strong {
  display: -webkit-box;
  margin-top: 5px;
  font-size: 13px;
  overflow: hidden;
  line-height: 1.35;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
}

.candidate-main small {
  margin-top: 5px;
}

.candidate-main b {
  width: 38px;
  height: 38px;
  flex-shrink: 0;
  display: grid;
  place-items: center;
  border-radius: 50%;
  color: #031018;
  background: linear-gradient(135deg, #7cf4ff, #67ffd0);
  box-shadow: 0 10px 24px rgba(103, 255, 208, 0.2);
}

.candidate-metrics {
  margin-top: 7px;
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 7px;
}

.candidate-metrics span {
  min-width: 0;
  padding: 5px 7px;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  border-radius: 999px;
  color: #9bf8ff;
  background: rgba(102, 236, 255, 0.08);
  font-size: 11px;
}

.candidate-remove {
  position: absolute;
  right: 12px;
  top: 12px;
  height: 26px;
  padding: 0 8px;
  border-radius: 8px;
  color: rgba(237, 250, 255, 0.72);
  background: rgba(255, 255, 255, 0.06);
  border: 1px solid rgba(255, 255, 255, 0.08);
  font-size: 12px;
}

.candidate-empty {
  margin-top: 14px;
  padding: 16px;
  border-radius: 14px;
  color: rgba(237, 250, 255, 0.62);
  background: rgba(255, 255, 255, 0.04);
  border: 1px dashed rgba(102, 236, 255, 0.22);
}

.candidate-empty strong,
.candidate-empty span {
  display: block;
}

.candidate-empty span {
  margin-top: 6px;
  font-size: 12px;
  line-height: 1.6;
}

.radar-meta {
  justify-content: space-between;
  font-size: 13px;
}

.radar-meta strong {
  color: #8fffee;
}

.bar {
  height: 8px;
  margin-top: 7px;
  overflow: hidden;
  border-radius: 999px;
  background: rgba(255, 255, 255, 0.08);
}

.bar div {
  height: 100%;
  border-radius: inherit;
  background: linear-gradient(90deg, #6cf6ff, #61ffa9);
}

.scenario-detail {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 10px;
  padding: 10px 12px;
  border-radius: 14px;
  border: 1px solid rgba(103, 255, 208, 0.18);
  background: linear-gradient(180deg, rgba(14, 54, 50, 0.86), rgba(6, 24, 30, 0.92));
}

.scenario-detail span {
  display: block;
  color: rgba(237, 250, 255, 0.54);
  font-size: 11px;
}

.scenario-detail strong {
  display: block;
  margin-top: 4px;
  font-size: 13px;
}

.scenario-tabs {
  display: flex;
  gap: 6px;
  flex-wrap: wrap;
  justify-content: center;
}

.scenario-tabs button {
  height: 28px;
  padding: 0 9px;
  border-radius: 999px;
  color: #9bf8ff;
  background: rgba(102, 236, 255, 0.08);
  border: 1px solid rgba(102, 236, 255, 0.14);
  font-size: 11px;
}

.scenario-tabs button.active {
  color: #031018;
  background: linear-gradient(135deg, #7cf4ff, #43e095);
}

.history-list {
  margin-top: 10px;
  display: grid;
  gap: 9px;
  max-height: 212px;
  overflow: auto;
}

.history-card.expanded .history-list {
  max-height: 240px;
  min-height: 180px;
  padding-right: 4px;
}

.history-item {
  width: 100%;
  padding: 9px;
  text-align: left;
  border-radius: 12px;
  color: #edfaff;
  background: rgba(255, 255, 255, 0.045);
  border: 1px solid rgba(255, 255, 255, 0.06);
}

.history-item span,
.history-item em {
  display: block;
  margin-top: 4px;
  font-size: 12px;
  color: rgba(237, 250, 255, 0.54);
  font-style: normal;
}

.agent-card {
  position: relative;
  height: 100%;
  min-height: 0;
  display: flex;
  flex-direction: column;
}

.agent-header {
  flex-shrink: 0;
  gap: 12px;
  padding-bottom: 14px;
  border-bottom: 1px solid rgba(255, 255, 255, 0.07);
}

.agent-header > div:nth-child(2) {
  flex: 1;
  min-width: 0;
}

.agent-avatar,
.avatar {
  flex-shrink: 0;
  display: grid;
  place-items: center;
  font-weight: 900;
}

.agent-avatar {
  width: 44px;
  height: 44px;
  border-radius: 13px;
  color: #031018;
  background: linear-gradient(135deg, #7cf4ff, #43e095);
}

.chat-history {
  position: absolute;
  z-index: 20;
  top: 78px;
  right: 16px;
  width: min(340px, calc(100% - 32px));
  max-height: 430px;
  overflow: auto;
  padding: 14px;
  border-radius: 16px;
  background: rgba(5, 17, 28, 0.98);
  border: 1px solid rgba(102, 236, 255, 0.18);
  box-shadow: 0 24px 70px rgba(0, 0, 0, 0.38);
}

.history-title-row {
  justify-content: space-between;
  margin-bottom: 10px;
}

.history-title-row button {
  width: 28px;
  height: 28px;
  border-radius: 8px;
  color: #fff;
  background: rgba(255, 255, 255, 0.08);
}

.messages {
  flex: 1;
  min-height: 0;
  overflow-y: auto;
  padding: 16px 2px 12px;
}

.message-row {
  display: flex;
  align-items: flex-start;
  gap: 10px;
  margin-bottom: 14px;
}

.message-row.user {
  flex-direction: row-reverse;
}

.avatar {
  width: 36px;
  height: 36px;
  border-radius: 12px;
  color: #9bf8ff;
  background: rgba(102, 236, 255, 0.1);
  border: 1px solid rgba(102, 236, 255, 0.14);
  font-size: 12px;
}

.bubble {
  max-width: 78%;
  padding: 13px 14px;
  border-radius: 15px;
  color: #edfaff;
  text-align: left;
  background: rgba(12, 39, 55, 0.9);
  border: 1px solid rgba(102, 236, 255, 0.12);
}

.message-row.user .bubble {
  background: rgba(26, 88, 101, 0.92);
}

.message-text {
  margin: 0;
  white-space: pre-wrap;
  word-break: break-word;
  line-height: 1.75;
  font-size: 14px;
}

.report-bubble {
  display: grid;
  gap: 7px;
  cursor: pointer;
  border-color: rgba(103, 255, 208, 0.28);
  background: linear-gradient(180deg, rgba(26, 105, 91, 0.94), rgba(9, 52, 58, 0.94));
}

.report-bubble span,
.report-bubble em {
  color: rgba(237, 250, 255, 0.68);
  font-style: normal;
  font-size: 12px;
}

.typing-bubble {
  display: flex;
  gap: 6px;
  min-width: 68px;
}

.typing-bubble span {
  width: 7px;
  height: 7px;
  border-radius: 50%;
  background: #67ffd0;
  animation: bounce 1.1s infinite ease-in-out;
}

.typing-bubble span:nth-child(2) {
  animation-delay: 0.14s;
}

.typing-bubble span:nth-child(3) {
  animation-delay: 0.28s;
}

.table-wrap {
  width: 100%;
  overflow-x: auto;
}

.rich-table {
  min-width: 520px;
  border-collapse: collapse;
}

.rich-table th,
.rich-table td {
  border: 1px solid rgba(255, 255, 255, 0.08);
  padding: 9px 10px;
  font-size: 13px;
}

.rich-table th {
  color: #8fffee;
  background: rgba(102, 236, 255, 0.1);
}

.input-zone {
  flex-shrink: 0;
  padding-top: 14px;
  border-top: 1px solid rgba(255, 255, 255, 0.07);
}

.context-strip {
  gap: 7px;
  margin-bottom: 10px;
  white-space: nowrap;
  overflow: hidden;
  font-size: 12px;
}

.context-strip span {
  color: rgba(237, 250, 255, 0.54);
}

.context-strip strong {
  overflow: hidden;
  text-overflow: ellipsis;
}

.context-strip em {
  color: #67ffd0;
  font-style: normal;
}

.input-row {
  gap: 9px;
}

.chat-input {
  min-width: 0;
  flex: 1;
  height: 46px;
  padding: 0 14px;
  border-radius: 12px;
}

.send-btn {
  width: 78px;
  border-radius: 12px;
  color: rgba(237, 250, 255, 0.7);
  background: rgba(102, 236, 255, 0.1);
  border: 1px solid rgba(102, 236, 255, 0.14);
  font-weight: 900;
}

.quick-list {
  margin-top: 10px;
  display: flex;
  gap: 8px;
  flex-wrap: wrap;
}

.quick-list button {
  height: 34px;
  padding: 0 11px;
  border-radius: 999px;
  color: #9bf8ff;
  background: rgba(102, 236, 255, 0.08);
  border: 1px solid rgba(102, 236, 255, 0.14);
  font-size: 12px;
}

.empty-hint {
  padding: 16px;
  text-align: center;
  color: rgba(237, 250, 255, 0.48);
  font-size: 13px;
}

.toast {
  position: fixed;
  z-index: 100;
  left: 50%;
  bottom: 28px;
  transform: translateX(-50%);
  padding: 11px 18px;
  border-radius: 999px;
  color: #fff;
  background: rgba(5, 17, 28, 0.95);
  border: 1px solid rgba(102, 236, 255, 0.2);
  box-shadow: 0 18px 52px rgba(0, 0, 0, 0.36);
}

@keyframes spin {
  to {
    transform: rotate(360deg);
  }
}

@keyframes bounce {
  0%,
  80%,
  100% {
    opacity: 0.35;
    transform: translateY(0);
  }
  40% {
    opacity: 1;
    transform: translateY(-5px);
  }
}

@keyframes scan {
  from {
    transform: translateY(-100%);
  }
  to {
    transform: translateY(100%);
  }
}

@media (max-width: 1240px) {
  .workspace {
    height: auto;
    min-height: calc(100vh - 82px);
    grid-template-columns: 1fr 1fr;
    overflow: auto;
  }

  .agent-panel {
    grid-column: 1 / -1;
    height: 680px;
  }

  .home-page {
    overflow: auto;
  }
}

@media (max-width: 820px) {
  .topbar {
    height: auto;
    padding: 16px;
    grid-template-columns: 1fr auto;
  }

  .top-metrics {
    grid-column: 1 / -1;
    justify-content: flex-start;
    overflow-x: auto;
  }

  .workspace {
    padding: 0 16px 18px;
    grid-template-columns: 1fr;
  }

  .decision-panel,
  .agent-panel {
    grid-column: auto;
  }

  .map-shell {
    height: 430px;
    flex: none;
  }

  .insight-row {
    grid-template-columns: repeat(2, 1fr);
  }

  .business-panel {
    grid-template-columns: repeat(2, minmax(0, 1fr));
  }
}

@media (max-width: 520px) {
  .brand-title {
    font-size: 20px;
  }

  .map-search-bar {
    right: 16px;
    top: 68px;
  }

  .map-chip {
    top: 16px;
  }

  .location-card {
    align-items: flex-start;
    flex-direction: column;
  }

  .insight-row {
    grid-template-columns: 1fr;
  }

  .business-panel {
    grid-template-columns: 1fr;
  }

  .field.wide {
    grid-column: auto;
  }

  .business-summary {
    align-items: flex-start;
    flex-direction: column;
  }

  .summary-actions,
  .candidate-actions {
    width: 100%;
    align-items: flex-start;
    flex-direction: column;
  }

  .bubble {
    max-width: 86%;
  }
}
</style>
